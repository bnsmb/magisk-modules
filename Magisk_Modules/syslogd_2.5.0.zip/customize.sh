#
# Customization script for the Magisk Module with the syslogd 
#
# History
#   25.08.2024 /bs
#     initial release
#
#
# Notes:
#
# This Magisk Module contains various the syslogd for arm64 CPUs
#
# The source for the syslogd is available on this website:  https://www.gnu.org/software/inetutils/inetutils.html
#
# Documentation for creating Magisk Modules: https://topjohnwu.github.io/Magisk/guides.html
#
# Environment variables that can be used:
#
#    MAGISK_VER (string): the version string of current installed Magisk (e.g. v20.0)
#    MAGISK_VER_CODE (int): the version code of current installed Magisk (e.g. 20000)
#    BOOTMODE (bool): true if the module is being installed in the Magisk app
#    MODPATH (path): the path where your module files should be installed
#    TMPDIR (path): a place where you can temporarily store files
#    ZIPFILE (path): your module’s installation zip
#    ARCH (string): the CPU architecture of the device. Value is either arm, arm64, x86, or x64
#    IS64BIT (bool): true if $ARCH is either arm64 or x64
#    API (int): the API level (Android version) of the device (e.g. 21 for Android 5.0)
#

# -----------------------------------------------------------------------------

# define constants
#
__TRUE=0
__FALSE=1


#exec 1>/data/local/tmp/customize.log 2>&1
set -x

# -----------------------------------------------------------------------------
# init global variables
#

MODULE_VERSION="$( grep "^version=" $MODPATH/module.prop  | cut -f2 -d "=" )"

CMD_PARAMETER=""

# -----------------------------------------------------------------------------

function LogMsg {
  ui_print "$*"
}

function LogInfo {
  LogMsg "INFO: $*"
}

function LogWarning {
  LogMsg "WARNING: $*"
}

function LogError {
  LogMsg "ERROR: $*"
}


# -----------------------------------------------------------------------------

LogMsg "The current environment for this installation is"

LogMsg "The version of the installed Magisk is \"${MAGISK_VER}\" (${MAGISK_VER_CODE})"

LogInfo "BOOTMODE is \"${BOOTMODE}\" "
LogInfo "MODPATH is \"${MODPATH}\" "
LogInfo "TMPDIR is \"${TMPDIR}\" "
LogInfo "ZIPFILE is \"${ZIPFILE}\" "
LogInfo "ARCH is \"${ARCH}\" "
LogInfo "IS64BIT is \"${IS64BIT}\" "
LogInfo "API is \"${API}\" "

# -----------------------------------------------------------------------------

# example output for the variables:


#  The version of the installed Magisk is "25.0" (25000)
#  INFO: BOOTMODE is "true" 
#  INFO: MODPATH is "/data/adb/modules_update/PlayStore_for_MicroG" 
#  INFO: TMPDIR is "/dev/tmp" 
#  INFO: ZIPFILE is "/data/user/0/com.topjohnwu.magisk/cache/flash/install.zip" 
#  INFO: ARCH is "arm64" 
#  INFO: IS64BIT is "true" 
#  INFO: API is "32"


# -----------------------------------------------------------------------------

LogMsg "Installing the Magisk Module with the syslogd \"${MODULE_VERSION}\" ..."

# LogMsg "Checking the OS configuration ..."

ERRORS_FOUND=${__FALSE}

MACHINE_TYPE="$( uname -m )"

# check the current CPU
#
LogMsg "Checking the type of the CPU used in this device ...."
LogMsg "The CPU in this device is a ${ARCH} CPU"
LogMsg "The machine type reported by \"uname -m\" is \"${MACHINE_TYPE}\" "

if [ "${ARCH}"x != "arm64"x ] ; then
  abort "This Magisk module is for arm and x86 CPUs only"
fi

# ---------------------------------------------------------------------

REPLACE_HOSTS_FILE=${__FALSE}


TEMPVAR="$( grep -v localhost /system/etc/hosts 2>/dev/null )"
if [ "${TEMPVAR}"x = ""x ] ; then
  REPLACE_HOSTS_FILE=${__TRUE}
fi

grep "### SYSLOGD ###" /system/etc/hosts 2>/dev/null  >/dev/null && REPLACE_HOSTS_FILE=${__TRUE}

if [ ${REPLACE_HOSTS_FILE} = ${__TRUE} ] ; then
  [ -r $MODPATH/system/etc/hosts.template ] && mv $MODPATH/system/etc/hosts.template  $MODPATH/system/etc/hosts
else
  echo "Looks like there is already a bind mount for \"/system/etc/hosts\" in place -- will not create a bind mount for that file"
fi


# ---------------------------------------------------------------------


LogMsg "Correcting the permissions for the new files ..."

for i in ${MODPATH}/*.sh ; do
  chmod 755 "${MODPATH}/$i"
done

for i in bin lib lib64 ; do
  [ ! -d "${MODPATH}/system/$i" ] && continue
  LogMsg "Processing the files in the directory ${MODPATH}/system/$i ..."

  set_perm_recursive "${MODPATH}/system/$i" 0 0 0755 0755 u:object_r:system_file:s0

  chcon -R -h  u:object_r:system_file:s0 "${MODPATH}/system/$i"
done

for i in usr/share etc ${NEW_TERMINFO_DIR} ; do
  
  [[ $i != /* ]] && CUR_ENTRY="${MODPATH}/system/$i" || CUR_ENTRY="$i"

  [ ! -d "${CUR_ENTRY}" ] && continue 
  
  LogMsg "Processing the files in the directory ${CUR_ENTRY} ..."
  set_perm_recursive "${CUR_ENTRY}" 0 0 0755 0644 u:object_r:system_file:s0
  chcon -R -h u:object_r:system_file:s0 "${CUR_ENTRY}"
done


