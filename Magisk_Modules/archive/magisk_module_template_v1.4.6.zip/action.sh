# 
# Magisk script action.sh for the Magisk Module
#
# Note: All messages written to STDOUT are displayed in the Magisk output window 
#
# History
#  31.10.2024 /bs
#     initial release
#   06.05.2025 /bs
#     added code to write messages to the Magisk output window even if STDOUT is redirected to a file  
#     added the variables MODULE_VERSION and MODULE_DESC
#     "set -x" is now only executed if the files /data/local/tmp/debug and /data/local/tmp/trace exist
#   22.09.2025 /bs
#     added the missing definitions for __TRUE and __FALSE
#     added the environment variable IN_ACTION_SCRIPT
#   24.09.2025 /bs
#     added the function ReadVolumeKeys
#   24.01.2026 /bs
#     the script now prints the process ID and the PPID to the log file if logging to a file is enabled
#   30.03.2026 /bs
#     replaced "typeset" with "local" in the function ReadVolumeKeys
#     added sample code to read the volume up and down keys
#     added sample code to show a user message in the Android GUI
#
#     
# Notes: 
#
# Do NOT use typeset in this script!
#
# To show a user message in the GUI use this command (may not work on all Android versions):
#
# su - shell -c ' cmd notification post -S bigtext toast "Hallo Welt from an Action Script" '
#
# Commands to unlock the phone (if necessary; 1234 is the PIN used in this example):
#
# input keyevent KEYCODE_WAKEUP
# wm dismiss-keyguard
# sleep 1
# input text 1234
# input keyevent KEYCODE_ENTER
#
# -----------------------------------------------------------------------------
# define some constants
#
__TRUE=0
__FALSE=1

export IN_ACTION__SCRIPT=${__TRUE}

# -----------------------------------------------------------------------------
#
# the environment variable MODPATH is only defined by Magisk for the script customize.sh
#
[ "${MODPATH}"x = ""x ] && MODPATH="${0%/*}"

MODULE_NAME="$( grep "^id=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"
[ "${MODULE_NAME}"x = ""x ] && MODULE_NAME="unknown_magisk_module"

MODULE_VERSION="$( grep "^version=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"

MODULE_DESC="${MODULE_NAME} ${MODULE_VERSION}"

# customize.sh is sourced in
# #
[ "$0"x = "sh"x ] && SCRIPT_NAME="customize.sh" || SCRIPT_NAME="${0##*/}"


# -----------------------------------------------------------------------------
# save the file handle for STDOUT to file handle 5 ( &5 is used in the function printMsg )
#
exec 5>&1

# ----------------------------------------------------------------------------
#
# printMsg - print a Message to the Magisk output window even if redirection of STDOUT to the logfile is enabled
# 
# Usage: printMsg [message]
#
function printMsg {
   echo "$*" >&5
}

# ----------------------------------------------------------------------------
#
# LogDebugMsg - print a Message if DEBUG_MODE is ${__TRUE}
# 
# Usage: LogDebugMsg [message]
#
function LogDebugMsg {
  if [ ${DEBUG_MODE} = ${__TRUE} ] ; then
    echo "$*"
  fi
}

# ---------------------------------------------------------------------
# ReadVolumeKeys - read the status of the volume keys
#
# Usage: ReadVolumeKeys [timeout] 
#
# Parameter:
#        timeout - timeout in seconds to wait; the default value is 10 seconds
#
# returns:
#        0 - no volume key pressed 
#        1 - volume up pressed
#        2 - volume down pressed
#        3 - power key pressed
#
function ReadVolumeKeys {
  local __FUNCTION="ReadVolumeKeys"

  local THISRC=0
   
  local DEFAULT_TIMEOUT=10
  
  local TIMEOUT="${DEFAULT_TIMEOUT}"
  local MESSAGE=""
  
  local dev=""
  local type=""
  local code=""
  local value=""
  
  local RESULT=""

  if [ $# -eq 1 ] ; then
    TIMEOUT=$1
    shift
  fi

# the variables dev, type, code, and value can not be used here because the "while" statement is running a separate session
#
  RESULT=$( timeout ${TIMEOUT} getevent -ql | while read dev type code value; do
    if [ "$code" = "KEY_VOLUMEUP" ] && [ "$value" = "DOWN" ]; then
      echo 1
      break
    elif [ "$code" = "KEY_VOLUMEDOWN" ] && [ "$value" = "DOWN" ]; then
      echo 2
      break
    elif  [ "$code" = "KEY_POWER" ] && [ "$value" = "DOWN" ]; then

# activate the display again (no pin necessary here -- at least in my tests ....)
# 	    
      input keyevent KEYCODE_WAKEUP
      echo 3
      break
    fi
  done )
   
  [ "${RESULT}"x != ""x ] && THISRC="${RESULT}"
  
  return ${THISRC}
}

# -----------------------------------------------------------------------------
# change either "0 = 1" to "0 = 0" in this script or create the file /data/local/tmp/debug to enable the debug output to the log file
#
if [ 0 = 1  -o -r /data/local/tmp/debug ] ; then
  LOGFILE="/data/local/tmp/${MODULE_NAME}_${SCRIPT_NAME}.log"

  printMsg  "----"
  printMsg  "Messages to STDOUT are now redirected to the log file 
  ${LOGFILE}"
  printMsg  "----"

  exec 1>"${LOGFILE}" 2>&1

  echo "The PID of this process is $$; the PPID is $PPID"

  if [ -r /data/local/tmp/trace ] ; then
    set -x
    TRACE_MODE=${__TRUE}
  else
    TRACE_MODE=${__FALSE}    
  fi

  DEBUG_MODE=${__TRUE}   
else
  DEBUG_MODE=${__FALSE}     
  TRACE_MODE=${__FALSE}
fi

# ----------------------------------------------------------------------------
# change the if clause to disable the example code
#
if [ 0 = 0 ] ; then
  printMsg "This message goes to the Magisk Output Window 
even if STDOUT is redirected to a file"

  echo "This message goes to the Magisk Output 
window if STDOUT is NOT redirected;
it goes to the logfile if STDOUT is redirected to a file"

  echo "This messages goes to the log file if STDERR 
is redirected to a file. It goes to the Nirvana if STDERR 
is NOT redirected" >&2

  echo ""
  echo "------------------------------ "
  echo ""

  echo "Time is now $( date  +%H:%M:%S )"

  echo "Now showing a notification in the Android GUI ..."
  su - shell -c ' cmd notification post -S bigtext toast "Hallo Welt from an Action Script at $( date  +%H:%M:%S ) " '

  echo ""
  echo "------------------------------ "
  echo ""

  echo "Time is now $( date  +%H:%M:%S )"
  echo "Press Volume Down now in the next 10 seconds "
  ReadVolumeKeys
  if [ $? -eq 2 ] ; then
	 echo "Volume Down pressed"
  else
	 echo "Volume Down NOT pressed"
  fi

  echo ""
  echo "------------------------------ "
  echo ""
 
  echo "Time is now $( date  +%H:%M:%S )" 
  echo "Press Volume Up now in the next 10 seconds "
  ReadVolumeKeys
  if [ $? -eq 1  ] ; then
         echo "Volume Up pressed"
  else
         echo "Volume Up NOT pressed"
  fi

  echo ""
  echo "------------------------------ "
  echo ""

  echo "Time is now $( date   +%H:%M:%S )"
  echo "Press any key in the next 10 seconds "
  ReadVolumeKeys
  case $? in
	 0 ) echo "No key pressed"
	    ;;
	 1 ) echo "Volume up key pressed"
	    ;;
	 2 ) echo "Volume down key pressed"
            ;;
	 3 ) echo "Power key pressed"
	    ;;
	 * ) echo "Unknown response found"
            ;;
  esac

fi

# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
