# 
# Magisk init script service.sh for the Magisk Module with dnsmasq
#
# History
#   04.04.2026 /bs
#     initial release
#
# use the command
#
#   resetprop -w sys.boot_completed 0
#
# to wait until the boot is complete
#
# Note: Do NOT use typeset in this script!
#
# -----------------------------------------------------------------------------
# define some constants
#
__TRUE=0
__FALSE=1

export IN_SERVICE_SCRIPT=${__TRUE}

# -----------------------------------------------------------------------------
#
# the environment variable MODPATH is only defined by Magisk for the script customize.sh
#
[ "${MODPATH}"x = ""x ] && MODPATH="${0%/*}"

MODULE_NAME="$( grep "^id=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"
[ "${MODULE_NAME}"x = ""x ] && MODULE_NAME="unknown_magisk_module"

MODULE_VERSION="$( grep "^version=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"

MODULE_DESC="${MODULE_NAME} ${MODULE_VERSION}"

# customize.sh is sourced in
# #
[ "$0"x = "sh"x ] && SCRIPT_NAME="customize.sh" || SCRIPT_NAME="${0##*/}"


# ----------------------------------------------------------------------------
# create a semphor to  avoid duplicate parallle execution 
#  
mkdir /dev/"${MODULE_NAME}" || exit


# ----------------------------------------------------------------------------
# remove the semaphor if it exists
#
function cleanup {
  [ -d /dev/"${MODULE_NAME}"  ] && rmdir /dev/"${MODULE_NAME}" 
}

trap "cleanup" 0

# ----------------------------------------------------------------------------
#
# LogDebugMsg - print a Message if DEBUG_MODE is ${__TRUE}
# 
# Usage: LogDebugMsg [message]
#
function LogDebugMsg {
  if [ ${DEBUG_MODE} = ${__TRUE} ] ; then
    echo "$*"
  fi
}

# -----------------------------------------------------------------------------
# change either "0 = 1" to "0 = 0" in this script or create the file /data/local/tmp/debug to enable the debug output to the log file
#
if [ 0 = 1 -o -r /data/local/tmp/debug ] ; then
  LOGFILE="/data/local/tmp/${MODULE_NAME}_${SCRIPT_NAME}.log"

#  echo "Writing all messages to the log file ${LOGFILE}"

  exec 1>"${LOGFILE}" 2>&1

  echo "The PID of this process is $$; the PPID is $PPID"
  
  if [ -r /data/local/tmp/trace ] ; then
    set -x
    TRACE_MODE=${__TRUE}
  else
    TRACE_MODE=${__FALSE}    
  fi
  
  DEBUG_MODE=${__TRUE}   
else
  DEBUG_MODE=${__FALSE}     
  TRACE_MODE=${__FALSE}  
fi


# -----------------------------------------------------------------------------
# functions
#

function LogMsg {
  echo "$*"
}

function LogInfo {
  LogMsg "INFO: $*"
}

function LogWarning {
  LogMsg "WARNING: $*"
}

function LogError {
  LogMsg "ERROR: $*"
}

# -----------------------------------------------------------------------------

# wait until the boot is complete:
#
# resetprop -w sys.boot_completed 0.
#

# -----------------------------------------------------------------------------
# check the pre requisites for the script
#

ERROR_LOG_FILE="/data/local/tmp/dnsmasq.log"

[ -r "${ERROR_LOG_FILE}" ] && rm -f "${ERROR_LOG_FILE}"

CUR_USER="$( id -un )"

CUR_OUTPUT="$( su -c uname -a 2>&1 )"
if [ $? -ne 0 ] ; then
  echo "${CUR_OUTPUT}"
  LogError  "The current user \"${CUR_USER}\" can not execute commands as user root"
  exit 5
fi

if [ "${MODPATH}"x = ""x ] ; then
  LogError "Can not detect the directory with this Magisk module"
  exit 6
fi

cd "${MODPATH}"
if [ $? -ne 0 ] ;then
  LogError "Can not change the working directory to the module directory \"${MODPATH}\" "
  exit 7
fi

if [ ! -r dnsmasq_env.sh ] ; then
  LogError "The file \"dnsmasq_env.sh\" does NOT exist in the directory \"${MODPATH}\": service.sh script aborted"
  exit 10
fi

LogMsg "Reading the environment file \"dnsmasq_env.sh\" ..."

unset DNSMASQ_ENV_INITIALIZED
source ./dnsmasq_env.sh

if [ $? -ne 0 -o "${DNSMASQ_ENV_INITIALIZED}"x != "0"x ] ; then
  LogError "The file \"dnsmasq_env.sh\" is incomplete or invalid:  service.sh script aborted"
  exit 20
fi


# -----------------------------------------------------------------------------

if [ "${DNSMASQ_STOP_FILE}"x != ""x ] ; then
  if [ -r "${DNSMASQ_STOP_FILE}" ] ; then
    LogMsg "File \"${DNSMASQ_STOP_FILE}\" found -- will not start the dnsmasq daemone"
    exit 0
  fi
fi

if [ -r "${DNSMASQ_START_OPTIONS_FILE}" ] ; then
  LogMsg "Reading the additional options for dnsmasq from the file \"${DNSMASQ_START_OPTIONS_FILE}\" ..."
  ADD_OPTIONS=$( cat "${DNSMASQ_START_OPTIONS_FILE}" | egrep -v "^$|^#" | tr "\n" " " )
  LogMsg "The additional options for dnsmasq are \"${ADD_OPTIONS}\" "
else
  ADD_OPTIONS=""
fi

LogMsg "Starting dnsmasq ..."
CUR_OUTPUT="$( ${DNSMASQ_BINARY} ${ADD_OPTIONS} 2>&1 )"

if [ $? -eq 0 ] ; then
  LogMsg "dnsmasq successfully started"
else
  ( LogMsg "Error starting dnsmasq: " ; LogMsg "${CUR_OUTPUT}" ) | tee  "${ERROR_LOG_FILE}"
fi

# -----------------------------------------------------------------------------
