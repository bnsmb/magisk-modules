#!/system/bin/sh
#
# This is a sample script that can be used as normal script in a shell or as action.sh script with a menu
# 
# Shell script for the Magisk Module to start/stop the nrpe daemon
#
# This script can be used as start / stop script in scripts and also
# as action.sh script in the Magisk module.
# If used as action.sh script, the script shows a menu and the user
# can select via VolumeUp and VolumeDown key the actions to execute.
#
# Note: 
#
# If executed as action.sh script all messages written to STDOUT are displayed in the Magisk output window 
#
#
# If the action script is used in a adb shell, the syntax for the script is:
#
#h#
#h#  start_stop_nrpe.sh [help] [start] [restart] [stop] [status] [enable] [disable] [viewlog] [var=value]
#h# 
#h# Parameter:
#h# 
#h#   help       - print the usage help and exit_program
#h#   start      - start the nrpe daemon
#h#   restart    - restart the nrpe daemon
#h#   stop       - stop the nrpe daemon
#h#   status     - print the status of the nrpe daemon
#h#   enable     - enable the automatic start of the nrpe daemon
#h#   disable    - disable the automatic start of the nrpe daemon
#h#   viewlog    - view the log file of the nrpe daemon
#h#   clear      - clear the log file
#h#   var=value  - set the variable "var" to the value "value"
#h#                this parameter can be used multiple times
#h#
#
# History
#  25.08.2026 /bs
#     initial release
#
#     
# Note: Do NOT use typeset in this script if it's used as action.sh script
#
#

# -----------------------------------------------------------------------------
# define some constants
#
__TRUE=0
__FALSE=1


# the variable ACTION_SCRIPT_RUNNING is set to ${__TRUE} by the script action.sh
#
[ "${ACTION_SCRIPT_RUNNING}"x = ""x ] &&  ACTION_SCRIPT_RUNNING=${__FALSE}

# constants for the physical keys
#
NO_KEY_PRESSED=0
VOLUME_UP_PRESSED=1
VOLUME_DOWN_PRESSED=2
POWER_PRESSED=3

# known config files for the nrpe daemon
#
CLANG19_NRPE_CONFIG_FILE1="/data/local/tmp/sysroot/etc/nrpe.cfg"
USER_NRPE_CONFIG_FILE="/data/local/tmp/nrpe.cfg"
DEFAULT_NRPE_CONFIG_FILE="/system/etc/nrpe.cfg"

# the nrpe daemon starts automatically after a reboot if this file exists
#
NRPE_START_SEM_FILE="/data/local/tmp/START_NRPE"

NRPE_BINARY="${NRPE_BINARY:=/system/bin/nrpe}"

# status variables
#
NRPE_RUNNING=""
NRPE_ENABLED=""

# additional parameter for starting nrpe
#
# -n = start nrpe without SSL support
#
NRPE_ADD_PARAMETER="${NRPE_ADD_PARAMETER:=-n}"
[ "${NRPE_ADD_PARAMETER}"x = "none"x ] && NRPE_ADD_PARAMETER=""


# -----------------------------------------------------------------------------
#
# the environment variable MODPATH is only defined by Magisk for the script customize.sh
#
[ "${MODPATH}"x = ""x ] && MODPATH="${0%/*}"

# correct the MODPATH variable if the script is executed in a shell
#
if [[ ${MODPATH} == */system/* ]] ; then
  MODPATH="/data/adb/modules/nrpe"
fi

if [ -r ${MODPATH}/module.prop ] ; then
  MODULE_NAME="$( grep "^id=" ${MODPATH}/module.prop   | cut -f2 -d "=" )"
  [ "${MODULE_NAME}"x = ""x ] && MODULE_NAME="unknown_magisk_module"

  MODULE_VERSION="$( grep "^version=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"

  MODULE_DESC="${MODULE_NAME} ${MODULE_VERSION}"
else
  MODULE_NAME="nrpe"
  MODULE_VERSION="1.4.3"
  MODULE_DESC="nrpe for Nagios"
fi

# customize.sh is sourced in
# #
[ "$0"x = "sh"x ] && SCRIPT_NAME="customize.sh" || SCRIPT_NAME="${0##*/}"

# -----------------------------------------------------------------------------
# save the file handle for STDOUT to file handle 5 ( &5 is used in the function printMsg )
#
exec 5>&1


# ----------------------------------------------------------------------------
#
# printMsg - print a Message to the Magisk output window even if redirection of STDOUT to the logfile is enabled
# 
# Usage: printMsg [message]
#
function printMsg {
   echo "$*" >&5
}

# -----------------------------------------------------------------------------
# change either "0 = 1" to "0 = 0" in this script or create the file /data/local/tmp/debug to enable the debug output to the log file
#
if [ 0 = 1  -o -r /data/local/tmp/debug ] ; then
  LOGFILE="/data/local/tmp/${MODULE_NAME}_${SCRIPT_NAME}.log"

  printMsg  "----"
  printMsg  "Messages to STDOUT are now redirected to the log file 
  ${LOGFILE}"
  printMsg  "----"

  exec 1>"${LOGFILE}" 2>&1

  echo "The PID of this process is $$; the PPID is $PPID"

  if [ -r /data/local/tmp/trace ] ; then
    set -x
    TRACE_MODE=${__TRUE}
  else
    TRACE_MODE=${__FALSE}    
  fi

  DEBUG_MODE=${__TRUE}   
else
  DEBUG_MODE=${__FALSE}     
  TRACE_MODE=${__FALSE}
fi


# ----------------------------------------------------------------------------
#
# LogDebugMsg - print a Message if DEBUG_MODE is ${__TRUE}
# 
# Usage: LogDebugMsg [message]
#
function LogDebugMsg {
  if [ ${DEBUG_MODE} = ${__TRUE} ] ; then
    echo "$*"
  fi
}

# ---------------------------------------------------------------------
# ReadVolumeKeys - read the status of the volume keys
#
# Usage: ReadVolumeKeys [timeout] 
#
# Parameter:
#        timeout - timeout in seconds to wait; the default value is 10 seconds
#                  use "none" or "-1" for no timeout
# returns:
#        0 - no volume key pressed (NO_KEY_PRESSED)
#        1 - volume up pressed (VOLUME_UP_PRESSED)
#        2 - volume down pressed (VOLUME_DOWN_PRESSED)
#        3 - power key pressed (POWER_PRESSED)
#
function ReadVolumeKeys {
  local __FUNCTION="ReadVolumeKeys"

  local THISRC=${NO_KEY_PRESSED}
      
  local TIMEOUT="${DEFAULT_TIMEOUT}"
  local MESSAGE=""
  
  local dev=""
  local type=""
  local code=""
  local value=""
  
  local RESULT=""

  local CUR_PREFIX=""
  
  if [ $# -eq 1 ] ; then
    TIMEOUT=$1
    shift
  fi

# the variables dev, type, code, and value can not be used here because the "while" statement is running a separate session
#
  if [ "${TIMEOUT}"x = "none"x -o "${TIMEOUT}"x = "-1"x -o "${TIMEOUT}"x = "0"x ] ; then
    CUR_PREFIX=""
  else
    CUR_PREFIX="timeout ${TIMEOUT}"
  fi
  
  RESULT=$( ${CUR_PREFIX} getevent -ql | while read dev type code value; do
    if [ "$code" = "KEY_VOLUMEUP" ] && [ "$value" = "DOWN" ]; then
      echo ${VOLUME_UP_PRESSED}
      break
    elif [ "$code" = "KEY_VOLUMEDOWN" ] && [ "$value" = "DOWN" ]; then
      echo ${VOLUME_DOWN_PRESSED}
      break
    elif  [ "$code" = "KEY_POWER" ] && [ "$value" = "DOWN" ]; then

# activate the display again (no pin necessary here -- at least in my tests ....)
# 
      input keyevent KEYCODE_WAKEUP
      echo ${POWER_PRESSED}
      break
    fi
  done )
   
  [ "${RESULT}"x != ""x ] && THISRC="${RESULT}"
  
  return ${THISRC}
}


# -----------------------------------------------------------------------------
# get the pid of the nrpe daemon if it's running
#
function get_nrpe_pid {
  local THISRC=${__TRUE}

  NRPE_PID=""
  
  if [ "${CUR_NRPE_CONFIG_FILE}"x != ""x ] ; then
    NRPE_PID_FILE="$( grep  "^pid_file="  "${CUR_NRPE_CONFIG_FILE}"  2>/dev/null | cut -f2 -d "=" )"
    if [ -r "${NRPE_PID_FILE}" ] ; then
      NRPE_PID="$( cat "${NRPE_PID_FILE}" )"
      if [ "${NRPE_PID}"x != ""x ] ; then
        ps -p ${NRPE_PID} >/dev/null || NRPE_PID=""
     fi
    fi
  fi
  
  if [ "${NRPE_PID}"x  = ""x ] ;  then
    NRPE_PID="$( ps -ef | grep -v grep | grep " nrpe " | grep " -c " | tail -1 | tr "\t" " " | tr -s " " | cut -f2 -d " " )"
  fi

  if [ "${NRPE_PID}"x  = ""x ] ;  then
    NRPE_RUNNING=${__FALSE}
    THISRC=${__FALSE}
  else
    NRPE_RUNNING=${__TRUE}
  fi

  return ${THISRC}
}

# -----------------------------------------------------------------------------

function start_nrpe_daemon {
  local THISRC=${__FALSE}

  echo "*** Starting the nrpe daemon ..."
  
  if [ "${NRPE_PID}"x != ""x ] ;  then
    echo "The nrpe daemon is already running - the PID is ${NRPE_PID}"
    THISRC=${__TRUE}
  elif [ "${CUR_NRPE_CONFIG_FILE}"x = ""x ] ; then
    echo "ERROR: No nrpe config file found"
  elif [ "${NRPE_BINARY}"x = ""x ] ; then
    echo "ERROR: No nrpe binary found"
  else
    echo "Starting the nrpe daemon with the config file \"${CUR_NRPE_CONFIG_FILE}\" ..."
    ${NRPE_BINARY} ${NRPE_ADD_PARAMETER} -c "${CUR_NRPE_CONFIG_FILE}" -d 
    if [ $? -eq 0 ] ; then
      THISRC=${__TRUE}
      NRPE_RUNNING=${__TRUE}
      get_nrpe_pid
    fi
  fi

  return ${THISRC}
}

# -----------------------------------------------------------------------------

function stop_nrpe_daemon {
  local THISRC=${__FALSE}

  echo "*** Stopping the nrpe daemon ..."

  if [ "${NRPE_PID}"x = ""x ] ;  then
    echo "The nrpe daemon is not running"
    THISRC=${__TRUE}  
  else
    echo "Stopping the nrpe daemon (PID=${NRPE_PID}) ..."
    su - -c kill ${NRPE_PID} 
    if [ $? -eq 0 ] ; then
      NRPE_PID=""
      THISRC=${__TRUE}
      NRPE_RUNNING=${__FALSE}
    fi
  fi

  return ${THISRC}
}

# -----------------------------------------------------------------------------

function restart_nrpe_daemon {

  local THISRC=${__FALSE}

  echo "*** Restarting the nrpe daemon ..."

  stop_nrpe_daemon 

  start_nrpe_daemon
  THISRC=$?
  
  return ${THISRC}
}

# -----------------------------------------------------------------------------

function status_nrpe_daemon {

  local THISRC=${__FALSE}
  
  echo "*** Retrieving the status of the nrpe daemon ..."
  
  if [ "${NRPE_PID}"x != ""x ] ;  then
    echo "The nrpe daemon is running:"
    echo
    ps -ef -p "${NRPE_PID}"
    THISRC=${__TRUE}
  else
    echo "The nrpe daemon is not running "
  fi
  echo

  if [ -r "${NRPE_START_SEM_FILE}" ] ; then
    NRPE_ENABLED="${__TRUE}"
    echo "The automatic start of the nrpe daemon is enabled"
  else
    NRPE_ENABLED="${__FALSE}"
    echo "The automatic start of the nrpe daemon is disabled"
  fi
  
  if [ "${CUR_NRPE_CONFIG_FILE}x " != ""x ] ; then   
    echo "The nrpe config file used now when (re)starting the nrpe daemon is:"
    echo " \"${CUR_NRPE_CONFIG_FILE}\" "
  else
    echo "WARNING : nprpe config file \"nrpe.cfg\" not found"
  fi

  return ${THISRC}  
}

# -----------------------------------------------------------------------------

function enable_nrpe_daemon {
  local THISRC=${__FALSE}
  
  echo "*** Enabling the nrpe daemon ..."

  if [ -r "${NRPE_START_SEM_FILE}" ] ; then
    echo "The automatic start of the nrpe daemon is already enabled"
    THISRC=${__TRUE}
  else
    echo "Enabling the automatic start of the nrpe daemon ..."
    su - -c touch "${NRPE_START_SEM_FILE}" 
    if [ $? -eq 0 ] ; then
      THISRC=${__TRUE}
      NRPE_ENABLED="${__TRUE}"
    else
      echo "ERROR: Can not create the file \"${NRPE_START_SEM_FILE}\" "
    fi
  fi  
  return ${THISRC}
}

# -----------------------------------------------------------------------------

function disable_nrpe_daemon {
  local THISRC=${__FALSE}
  
  echo "*** Disabling the nrpe daemon ..."

  if [ ! -r "${NRPE_START_SEM_FILE}" ] ; then
    echo "The automatic start of the nrpe daemon is already disabled"
    THISRC=${__TRUE}
  else
    echo "Disabling the automatic start of the nrpe daemon ..."
    su - -c rm -f "${NRPE_START_SEM_FILE}" 
    if [ $? -eq 0 ] ; then
      THISRC=${__TRUE}
      NRPE_ENABLED="${__FALSE}"
    else
      echo "ERROR: Can not delete the file \"${NRPE_START_SEM_FILE}\" "
    fi
  fi  
  return ${THISRC}
}

# -----------------------------------------------------------------------------

function view_nrpe_logfile {
  local THISRC=${__FALSE}

  local PAGER="cat"
  
  echo "*** View the log file of the nrpe daemon ..."

  if [ "${CUR_NRPE_LOGFILE}"x = ""x ] ; then
    echo "WARNING: No nrpe log file found"
  else
 
    if [ ${ACTION_SCRIPT_RUNNING} != ${__TRUE} ] ; then
      PAGER="$( which less )" || PAGER="$( which more )" || PAGER="$( which cat )"
    fi

    echo "*** cat ${CUR_NRPE_LOGFILE} "
    ${PAGER} "${CUR_NRPE_LOGFILE}"
    THISRC=${__TRUE}   
     
  fi

  return ${THISRC}
}


# -----------------------------------------------------------------------------

function clear_nrpe_logfile {
  local THISRC=${__FALSE}
  
  echo "*** Clear the log file of the nrpe daemon ..."

  if [ "${CUR_NRPE_LOGFILE}"x = ""x ] ; then
    echo "WARNING: No nrpe log file found"
  else
    echo >"${CUR_NRPE_LOGFILE}" 
    if [ $? -eq 0 ] ; then
       echo "${CUR_NRPE_LOGFILE} cleared"
      THISRC=${__TRUE}
    else
      echo "ERROR: Error clearing the logfile"
    fi
  fi

  return ${THISRC}
}

# -----------------------------------------------------------------------------

function update_status_message { 

   local CUR_MSG=""

   if [ ${NRPE_RUNNING} = ${__TRUE} ] ; then
     if [ ${NRPE_ENABLED} = ${__TRUE} ] ; then
       CUR_MSG="nrpe is enabled and running (PID=${NRPE_PID}) "
     else
       CUR_MSG="nrpe is running (PID=${NRPE_PID}) but not enabled"
     fi
   else
     if [ ${NRPE_ENABLED} = ${__TRUE} ] ; then
       CUR_MSG="nrpe is enabled but not running"
     else
       CUR_MSG="nrpe is not enabled and not running"
     fi
  fi   
  su - -c " sed -i -e \"s/^description=.*/description=${CUR_MSG} /g\" ${MODPATH}/module.prop "
}

# -----------------------------------------------------------------------------

function exit_program {
  
  update_status_message

  echo "The script ends with RC=${THISRC}"
  
  exit ${THISRC}
}

# -----------------------------------------------------------------------------

function init_nrpe_env {

#
# get the pid of the running nrpe daemon
#
  get_nrpe_pid

# 
# search the nrpe config file to use
#
  if [ "${NRPE_CONFIG_FILE}"x != ""x ] ; then
    CUR_NRPE_CONFIG_FILE="${NRPE_CONFIG_FILE}"
  elif [ -r "${CLANG19_NRPE_CONFIG_FILE}" ] ; then
    CUR_NRPE_CONFIG_FILE="${CLANG19_NRPE_CONFIG_FILE}"
  elif [ -r "${USER_NRPE_CONFIG_FILE}" ] ; then
    CUR_NRPE_CONFIG_FILE="${USER_NRPE_CONFIG_FILE}"
  elif [ -r "${DEFAULT_NRPE_CONFIG_FILE}" ] ; then
    CUR_NRPE_CONFIG_FILE="${DEFAULT_NRPE_CONFIG_FILE}"
  else
    CUR_NRPE_CONFIG_FILE=""
  fi

  if [ "${CUR_NRPE_CONFIG_FILE}"x != ""x ] ; then
    CUR_NRPE_LOGFILE="$( grep "^log_file="  "${CUR_NRPE_CONFIG_FILE}" | cut -f2 -d "="   )"
  else
    CUR_NRPE_LOGFILE=""
  fi

  if [ -r "${NRPE_START_SEM_FILE}" ] ; then
    NRPE_ENABLED="${__TRUE}"
  else
    NRPE_ENABLED="${__FALSE}"
  fi
  
}

# -----------------------------------------------------------------------------

function print_menu_header {

#
# get the pid of the running nrpe daemon and the current config file
#
  init_nrpe_env

#  
# default action is to start the nrpe daemon if it is not running or stop the daemon if it's running
#
  if [ "${CUR_ACTION}"x = ""x ] ; then
    [ "${NRPE_PID}"x  = ""x ] &&  CUR_ACTION="1" || CUR_ACTION="2"
  fi
  
  if [ "${NRPE_PID}"x  != ""x ] ;  then
    echo "The nrpe daemon is running:"
    echo
    ps -ef -p "${NRPE_PID}"
  else
    echo "The nrpe daemon is not running "
  fi
  echo
  
  if [ "${CUR_NRPE_CONFIG_FILE}x " != ""x ] ; then   
    echo "The nrpe config file is:"
    echo " \"${CUR_NRPE_CONFIG_FILE}\" "
  else
    echo "WARNING : nprpe config file \"nrpe.cfg\" not found"
    CUR_NRPE_LOGFILE=""
  fi

  echo
  if [ -r "${NRPE_START_SEM_FILE}" ] ; then
    NRPE_ENABLED="${__TRUE}"
    echo "The automatic start of the nrpe daemon is enabled"
  else
    NRPE_ENABLED="${__FALSE}"
    echo "The automatic start of the nrpe daemon is disabled"
  fi

}

# -----------------------------------------------------------------------------
# main function
#

# get the pid of the running nrpe daemon and the current config file

  init_nrpe_env

# -----------------------------------------------------------------------------
# process the parameter
#
# show the usage help if the script is called in an adb shell without any parameter 
#
if [ $# -eq 0 -a ${ACTION_SCRIPT_RUNNING} != ${__TRUE} ] ; then
  set "help"
fi  

if [ $# -ne 0 ] ; then

  SHOW_MENU=${__FALSE}
  
  THISRC=0

  while [ $# -ne 0 ] ; do
    CUR_PARAMETER="$1"
    shift
    
    case ${CUR_PARAMETER} in
    
      help  )
        grep "^#h#" $0 | cut -c4-
        exit 0
        ;;

      *=* )
        echo "Executing now \"${CUR_PARAMETER}\" ..."
        eval ${CUR_PARAMETER}
        if [ $? -ne 0 ] ; then
          echo "ERROR: Error executing \"${CUR_PARAMETER}\" "
          break
        fi
        ;;

      start )
        start_nrpe_daemon
        THISRC=$?
        ;;

      stop )
        stop_nrpe_daemon
        THISRC=$?
        ;;

      restart )
        restart_nrpe_daemon
        THISRC=$?
        ;;

      status )
        status_nrpe_daemon
        THISRC=$?
        ;;

      enable )
        enable_nrpe_daemon
        THISRC=$?
        ;;
        
      disable )
        disable_nrpe_daemon
        THISRC=$?
        ;;
        
      viewlog | log )
        view_nrpe_logfile
        THISRC=$?
        ;;

     clearlog )
        clear_nrpe_logfile
        THISRC=$?
        ;;

#
# hidden parameter to use the menu if called in an adb shell -- this parameter is for debugging only
#
      menu )
        SHOW_MENU=${__TRUE}
        ;;

      * )
        echo "ERROR: Unknown parameter found: \"${CUR_PARAMETER}\" "
        exit 5
        ;;
    esac

  done

  if [ ${SHOW_MENU} != ${__TRUE} ] ; then
    exit_program ${THISRC}
  fi
fi
 
 
# -----------------------------------------------------------------------------
# menu entries 
#


i=0
let i=i+1 ; MENU[$i]="Start the nrpe daemon"            # menu entry
            MENU_ACTION[$i]="start_nrpe_daemon"         # command to execute if this menu entry is selected

let i=i+1 ; MENU[$i]="Stop the nrpe daemon"
            MENU_ACTION[$i]="stop_nrpe_daemon"

let i=i+1 ; MENU[$i]="Restart the nrpe daemon"
            MENU_ACTION[$i]="restart_nrpe_daemon"

let i=i+1 ; MENU[$i]="Enable the nrpe daemon"
            MENU_ACTION[$i]="enable_nrpe_daemon"

let i=i+1 ; MENU[$i]="Disable the nrpe daemon"
            MENU_ACTION[$i]="disable_nrpe_daemon"

let i=i+1 ; MENU[$i]="View the nrpe logfile"
            MENU_ACTION[$i]="view_nrpe_logfile"

let i=i+1 ; MENU[$i]="Clear the nrpe logfile"
            MENU_ACTION[$i]="clear_nrpe_logfile"

let i=i+1 ; MENU[$i]="Refresh the menu"
            MENU_ACTION[$i]="echo"

let i=i+1 ; MENU[$i]="Quit"
            MENU_ACTION[$i]="exit_program"

MENU_ITEMS=$i

CUR_ACTION=""

CUR_TIMEOUT=${READ_TIMEOUT:=10}

# print the menu
#
while true ; do

  print_menu_header  
  
  echo
  echo "Menu"
  echo "----"
  echo
  i=0 ; while [ $i -lt ${MENU_ITEMS} ] ; do
    let i=i+1
    [ ${CUR_ACTION} = $i ] && ENTRY_PREFIX="> " || ENTRY_PREFIX="  "
    echo "${ENTRY_PREFIX}${MENU[$i]}"
  done
  echo
  echo "Press VolumeUp or VolumeDown to select"
  echo "Press Power to execute the item"
  if [ ${CUR_TIMEOUT} -gt 0 ] ; then
    echo "[ $( date ) ] "
    echo "The current action will be executed in ${CUR_TIMEOUT} seconds"
    echo "(Pressing VolumeUp or VolumeDown disables the timeout)"
  fi
  echo ">> "
  ReadVolumeKeys ${CUR_TIMEOUT}
  KEY_PRESSED=$?

  case ${KEY_PRESSED} in

    ${VOLUME_DOWN_PRESSED} )
      CUR_TIMEOUT=-1
      [ ${CUR_ACTION} -lt ${MENU_ITEMS} ] && let CUR_ACTION=CUR_ACTION+1 || CUR_ACTION=1
      ;;
    
    ${VOLUME_UP_PRESSED} )
      CUR_TIMEOUT=-1
      [ ${CUR_ACTION} -gt 1 ] && let CUR_ACTION=CUR_ACTION-1 || CUR_ACTION=${MENU_ITEMS}
      ;;
  
    ${POWER_PRESSED} | ${NO_KEY_PRESSED} )

      if [ ${KEY_PRESSED} = ${NO_KEY_PRESSED} ] ; then
        echo "No key pressed -- now executing \"${MENU[${CUR_ACTION}]}\" ..."
      else
        CUR_TIMEOUT=-1
      fi

      echo
      echo " ---------------------------------------------------------  "
      eval ${MENU_ACTION[${CUR_ACTION}]}
      echo
      echo " ---------------------------------------------------------  "

# exit the menu if no key was pressed
#      
      if [ ${KEY_PRESSED} = ${NO_KEY_PRESSED} ] ; then
        exit_program
      fi
     ;;

  esac
done
        

# -----------------------------------------------------------------------------
# this code should never be executed ...
#

exit_program

# -----------------------------------------------------------------------------



  

