# 
# Magisk script action.sh for the Magisk Module
#
# History
#   03.05.2025 /bs
#     initial release
#     
#

# -----------------------------------------------------------------------------
#
# the environment variable MODPATH is only defined by Magisk for the script customize.sh
#
[ "${MODPATH}"x = ""x ] && MODPATH="${0%/*}"

MODULE_NAME="$( grep "^id=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"
[ "${MODULE_NAME}"x = ""x ] && MODULE_NAME="unknown_magisk_module"

# customize.sh is sourced in
# #
[ "$0"x = "sh"x ] && SCRIPT_NAME="customize.sh" || SCRIPT_NAME="${0##*/}"

# -----------------------------------------------------------------------------
# change either "0 = 1" to "0 = 0" in this script or create the file /data/local/tmp/debug to enable the debug output to the log file
#
if [ 0 = 1 -o -r /data/local/tmp/debug ] ; then
  LOGFILE="/data/local/tmp/${MODULE_NAME}_${SCRIPT_NAME}.log"

#  echo "Writing all messages to the log file ${LOGFILE}"

  exec 1>"${LOGFILE}" 2>&1
  set -x
fi

# -----

SOCAT_STOP_FILE="/data/local/tmp/enable_wireless_adb/do_not_restart_socat"
touch "${SOCAT_STOP_FILE}"

# keep this code for the future
# 
if [ 0 = 1 ] ; then
	
if [ -r ${SOCAT_STOP_FILE} ] ; then
  echo "Deleting the file \"${SOCAT_STOP_FILE}\" at $( date )"
  rm "${SOCAT_STOP_FILE}"
else
  echo "Creating the file \"${SOCAT_STOP_FILE}\" at $( date )"
  touch "${SOCAT_STOP_FILE}"
fi

fi

