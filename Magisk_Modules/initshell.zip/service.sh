#  module init script (executed each time the module is loaded)
#
# To use: Add useful code and make the file executable via "chmod -x service.sh"
#
