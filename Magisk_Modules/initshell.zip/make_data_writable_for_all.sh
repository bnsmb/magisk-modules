# 
# for debugging the execution of /etc/profile by a non-root user  copy this file to 
#
# /data/adb/post-fs-data.d/make_data_writable_for_all.sh 
#
# and make it executable
#
# Note: 
#
# For security reason it's strongly recommended to delete the script /data/adb/post-fs-data.d/make_data_writable_for_all.sh after the debugging is finished!
# In addition you should enable SElinux again using  "setenforce 1"
#
#
    echo "Change /data/profile.log to writable for all at $( date ) ..." >>/data/postfstdata.log
    touch /data/profile.log
    chmod 777 /data /data/profile.log

    setenforce 0
