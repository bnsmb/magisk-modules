echo "Adding the SELinux policies for the ASUS Hardware Test Tool ..."
magiskpolicy  --live "allow system_app proc_stat file ioctl"
magiskpolicy  --live "allow system_app proc_stat file read"
magiskpolicy  --live "allow system_app proc_stat file getattr"
magiskpolicy  --live "allow system_app proc_stat file lock"
magiskpolicy  --live "allow system_app proc_stat file map"
magiskpolicy  --live "allow system_app proc_stat file open"
magiskpolicy  --live "allow system_app proc_stat file watch"
magiskpolicy  --live "allow system_app proc_stat file watch_reads"


