

## Notes

This Magisk Module  disables the fake store installed by default in the OmniROM with MicroG

Documentation for creating Magisk Modules: [Magisk Develop Documentation](https://topjohnwu.github.io/Magisk/guides.html)

History

v1.0.0 04.06.2023 /bs
  initial version

