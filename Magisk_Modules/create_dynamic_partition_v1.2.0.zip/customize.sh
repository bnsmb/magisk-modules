#
# Customization script for the Magisk Module with the scripts and binaries to create dynamic partitions
#
# History
#   08.11.2024 /bs
#     initial release
#   14.02.2025 /bs
#     added code to configure symbolic links for dmctl if necessary and possible
#
#
# Notes:
#
# This Magisk Module contains files for arm64 CPUs
#
# Documentation for creating Magisk Modules: https://topjohnwu.github.io/Magisk/guides.html
#
# Environment variables that can be used:
#
#    MAGISK_VER (string): the version string of current installed Magisk (e.g. v20.0)
#    MAGISK_VER_CODE (int): the version code of current installed Magisk (e.g. 20000)
#    BOOTMODE (bool): true if the module is being installed in the Magisk app
#    MODPATH (path): the path where your module files should be installed
#    TMPDIR (path): a place where you can temporarily store files
#    ZIPFILE (path): your module’s installation zip
#    ARCH (string): the CPU architecture of the device. Value is either arm, arm64, x86, or x64
#    IS64BIT (bool): true if $ARCH is either arm64 or x64
#    API (int): the API level (Android version) of the device (e.g. 21 for Android 5.0)
#

# -----------------------------------------------------------------------------

# define constants
#
__TRUE=0
__FALSE=1

# -----------------------------------------------------------------------------
# init global variables
#

MODULE_VERSION="$( grep "^version=" $MODPATH/module.prop  | cut -f2 -d "=" )"

MODULE_NAME="$( grep "^id=" $MODPATH/module.prop  | cut -f2 -d "=" )"

MODULE_DESC="${MODULE_NAME} ${MODULE_VERSION}"


# -----------------------------------------------------------------------------
#
if [ 0 = 1 -o -r /data/local/tmp/debug ] ; then
  LOGFILE="/data/local/tmp/${MODULE_NAME}_customize.log"

  ui_print "Writing all messages to the log file ${LOGFILE}"
  exec 1>${LOGFILE} 2>&1
  set -x
fi

# -----------------------------------------------------------------------------

CONFIG_FILE="/system/etc/process_dynamic_partition.conf"


# -----------------------------------------------------------------------------

function LogMsg {
  ui_print "$*"
}

function LogInfo {
  LogMsg "INFO: $*"
}

function LogWarning {
  LogMsg "WARNING: $*"
}

function LogError {
  LogMsg "ERROR: $*"
}


# -----------------------------------------------------------------------------

LogMsg "The current environment for this installation is"

LogMsg "The version of the installed Magisk is \"${MAGISK_VER}\" (${MAGISK_VER_CODE})"

LogInfo "BOOTMODE is \"${BOOTMODE}\" "
LogInfo "MODPATH is \"${MODPATH}\" "
LogInfo "TMPDIR is \"${TMPDIR}\" "
LogInfo "ZIPFILE is \"${ZIPFILE}\" "
LogInfo "ARCH is \"${ARCH}\" "
LogInfo "IS64BIT is \"${IS64BIT}\" "
LogInfo "API is \"${API}\" "

# -----------------------------------------------------------------------------

# example output for the variables:


#  The version of the installed Magisk is "25.0" (25000)
#  INFO: BOOTMODE is "true" 
#  INFO: MODPATH is "/data/adb/modules_update/PlayStore_for_MicroG" 
#  INFO: TMPDIR is "/dev/tmp" 
#  INFO: ZIPFILE is "/data/user/0/com.topjohnwu.magisk/cache/flash/install.zip" 
#  INFO: ARCH is "arm64" 
#  INFO: IS64BIT is "true" 
#  INFO: API is "32"


# -----------------------------------------------------------------------------

LogMsg "Installing the Magisk Module with ${MODULE_NAME} for Android \"${MODULE_VERSION}\" ..."

LogMsg "Checking the OS configuration ..."

ERRORS_FOUND=${__FALSE}

MACHINE_TYPE="$( uname -m )"

# check the current CPU
#
LogMsg "Checking the type of the CPU used in this device ...."

LogMsg "The CPU in this device is a ${ARCH} CPU"
LogMsg "The machine type reported by \"uname -m\" is \"${MACHINE_TYPE}\" "


if [ "${ARCH}"x != "arm64"x ] ; then
  abort "This Magisk module is for arm64 CPUs only"
fi

# ---------------------------------------------------------------------

LogMsg "Installing scripts and binaries to create dynamic partitions for Android ..."

LogMsg "Correcting the permissions for the new files ..."

cd "${MODPATH}"

# first the directories with data and config files 
# 
for i in etc include usr ; do

  [[ $i != /\* ]] && CUR_ENTRY="${MODPATH}/system/$i" || CUR_ENTRY="$i"

  [ ! -d "${CUR_ENTRY}" ] && continue

  LogMsg "Processing the files in the directory ${CUR_ENTRY} ..."
  set_perm_recursive "${CUR_ENTRY}" 0 0 0755 0644 u:object_r:system_file:s0
  chcon -R -h u:object_r:system_file:s0 "${CUR_ENTRY}"
done


# now the directories with binaries
# 
for i in bin lib lib64 usr/bin usr/libexec usr/create_dynamic_partition_tools ; do

  [[ $i != /\* ]] && CUR_ENTRY="${MODPATH}/system/$i" || CUR_ENTRY="$i"
	
  [ ! -d "${CUR_ENTRY}" ] && continue

  LogMsg "Processing the files in the directory ${CUR_ENTRY} ..."

  set_perm_recursive "${CUR_ENTRY}" 0 0 0755 0755 u:object_r:system_file:s0

  chcon -R -h  u:object_r:system_file:s0 "${CUR_ENTRY}"
done


# if this is an update of the Magisk Module keep the existing config file
#
if [ -r "${CONFIG_FILE}" ] ; then
  LogMsg "Found an existing config file \"${CONFIG_FILE}\" ..."
  LogMsg "Keeping the existing config file; the new config file is \"${MODPATH}${CONFIG_FILE}.new\" "
  cp "${MODPATH}${CONFIG_FILE}" "${MODPATH}${CONFIG_FILE}.new"
  cp "${CONFIG_FILE}" "${MODPATH}${CONFIG_FILE}"
fi

[ -r "${MODPATH}${CONFIG_FILE}" ] && chown shell:shell "${MODPATH}${CONFIG_FILE}"

chmod 755 "${MODPATH}/service.sh"


# create the symbolic link for the dmctl binary in the Magisk Module if there is no dmctl binary available in the running Android OS
#

SDK_BUILD_VERSION_PROPERTY="ro.build.version.sdk"

DMCTL_FOUND=${__FALSE}

DMCTL="$( which dmctl )"
if [ "${DMCTL}"x != ""x ] ; then
  LogMsg "The dmctl binary exists in the running Android OS :"
  ls -l "${DMCTL}"

  DMCTL_FOUND=${__TRUE}

else

  LogMsg "No dmctl binary found in the running Android OS "

  SDK_BUILD_VERSION="$( getprop ${SDK_BUILD_VERSION_PROPERTY} )"
  
  if [ "${SDK_BUILD_VERSION}"x = ""x ] ; then
    LogMsg "WARNING: Can not read the property \"${SDK_BUILD_VERSION_PROPERTY}\" "
  else
    LogMsg "The Android API version of the running OS is ${SDK_BUILD_VERSION} "

    DMCTL="${MODPATH}/system/usr/create_dynamic_partition_tools/dmctl_binaries/${SDK_BUILD_VERSION}/dmctl_android${SDK_BUILD_VERSION}"
    if [ -r "${DMCTL}" ] ; then
      LogMsg "Found the dmctl binary for the running Android OS in the Magisk Module:"
      ls -l "${DMCTL}"
      LogMsg "Creating the symlink for the binary ..."
      ln -s ../usr/create_dynamic_partition_tools/dmctl_binaries/${SDK_BUILD_VERSION}/dmctl_android${SDK_BUILD_VERSION} ${MODPATH}/system/bin/dmctl
      ls -l  ${MODPATH}/system/bin/dmctl

      DMCTL_FOUND=${__TRUE}
    fi
  fi

  if [ ${DMCTL_FOUND} != ${__TRUE} ] ; then
    LogMsg "No dmctl binary found for the Android API version ${SDK_BUILD_VERSION}"
    DMCTL=""
    LogMsg "Checking all dmctl binaries in the Magisk Module now ..."
    cd ${MODPATH}/system/usr/create_dynamic_partition_tools/dmctl_binaries
    for CUR_API_VERSION in * ; do
      LogMsg "Checking the dmctl binary for Android ${CUR_API_VERSION} ..."
      ${PWD}/${CUR_API_VERSION}/dmctl_android${CUR_API_VERSION} help 2>/dev/null >/dev/null
      if [ $? -eq 0 ] ; then
        LogMsg "The dmctl binary \"${PWD}/${CUR_API_VERSION}/dmctl_android${CUR_API_VERSION}\" works"
        LogMsg "Creating the symlink for the binary ..."
        ln -s ../usr/create_dynamic_partition_tools/dmctl_binaries/${CUR_API_VERSION}/dmctl_android${CUR_API_VERSION} ${MODPATH}/system/bin/dmctl
        ls -l  ${MODPATH}/system/bin/dmctl

        DMCTL_FOUND=${__TRUE}

        break
      fi
    done
  fi

fi

if [ ${DMCTL_FOUND} != ${__TRUE} ] ; then
  LogMsg "ERROR: No working dmctl binary found"
fi


