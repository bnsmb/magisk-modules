# 
# Magisk script action.sh for the Magisk Module
#
# History
#   03.05.2025 /bs
#     initial release
#   07.05.2025 /bs
#     the script now also stops the socat process if the action is disabled
#     the action button is now a switch to disable or enable socat
#     the script now prints messages to the Magisk Window while running
#     the script now updates the module description in the Magisk Module list
#


# -----------------------------------------------------------------------------

__TRUE=0
__FALSE=1

# -----------------------------------------------------------------------------
#
# the environment variable MODPATH is only defined by Magisk for the script customize.sh
#
[ "${MODPATH}"x = ""x ] && MODPATH="${0%/*}"

# read module infos
#
MODULE_NAME="$( grep "^id=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"
[ "${MODULE_NAME}"x = ""x ] && MODULE_NAME="unknown_magisk_module"

# customize.sh is sourced in
# #
[ "$0"x = "sh"x ] && SCRIPT_NAME="customize.sh" || SCRIPT_NAME="${0##*/}"

MODULE_PROP="${MODPATH}/module.prop"

# socat binary used by the module
#
SOCAT_NAME="socat"
SOCAT="$( cd "${MODPATH}" && echo "$PWD/system/bin/${SOCAT_NAME}" )"

# -----------------------------------------------------------------------------
# save the file handle for STDOUT to file handle 5 ( &5 is used in the function printMsg )
#
exec 5>&1

# ----------------------------------------------------------------------------
#
# printMsg - print a Message into the Magisk GUI Window even if redirection of STDOUT to the logfile is enabled
# 
# Usage: printMsg [message]
#
function printMsg {
   echo "$*" >&5
}

# ----------------------------------------------------------------------------
#
# LogDebugMsg - print a Message if DEBUG_MODE is ${__TRUE}
# 
# Usage: LogDebugMsg [message]
#
function LogDebugMsg {
  if [ ${DEBUG_MODE} = ${__TRUE} ] ; then
    echo "$*"
  fi
}

# -----------------------------------------------------------------------------
# change either "0 = 1" to "0 = 0" in this script or create the file /data/local/tmp/debug to enable the debug output to the log file
#
if [ 0 = 1  -o -r /data/local/tmp/debug ] ; then
  LOGFILE="/data/local/tmp/${MODULE_NAME}_${SCRIPT_NAME}.log"

  printMsg  "----"
  printMsg  "Messages to STDOUT are now redirected to the log file 
  ${LOGFILE}"
  printMsg  "----"

  exec 1>"${LOGFILE}" 2>&1
  
  if [ -r /data/local/tmp/trace ] ; then
    set -x
  fi
  
  DEBUG_MODE=${__TRUE}   
else
  DEBUG_MODE=${__FALSE}
fi

# ----------------------------------------------------------------------
#
# read the values from the script start_adb_via_wifi.sh
#
DATA_DIR="$( grep "^DATA_DIR=" ${MODPATH}/system/bin/start_adb_via_wifi.sh  | tail -1 | cut -f2 -d "="  )"
eval DATA_DIR="${DATA_DIR:=/data/local/tmp/enable_wireless_adb}"

DEFAULT_SLEEP_INTERVALL="$( grep "^DEFAULT_SLEEP_INTERVALL=" ${MODPATH}/system/bin/start_adb_via_wifi.sh  | tail -1 | cut -f2 -d "="  )"
eval DEFAULT_SLEEP_INTERVALL=${DEFAULT_SLEEP_INTERVALL:=4}

SOCAT_STOP_FILE="$( grep "^DISABLE_SOCAT_RESTART_SEMFILE=" ${MODPATH}/system/bin/start_adb_via_wifi.sh  | tail -1 | cut -f2 -d "="  )"
eval SOCAT_STOP_FILE=${SOCAT_STOP_FILE:=${DATA_DIR}/do_not_restart_socat}

CURRENT_SOCAT_PORT_FILE="$( grep "^CURRENT_SOCAT_PORT_FILE=" ${MODPATH}/system/bin/start_adb_via_wifi.sh  | tail -1 | cut -f2 -d "="  )"
eval CURRENT_SOCAT_PORT_FILE=${CURRENT_SOCAT_PORT_FILE:=${DATA_DIR}/current_adb_wifi_port}

CURRENT_SOCAT_PORT_FILE="${DATA_DIR}/current_adb_wifi_port"

if [ -r "${CURRENT_SOCAT_PORT_FILE}" ] ; then
  CURRENT_SOCAT_PORT="$( grep -E -v "^$|^#" "${CURRENT_SOCAT_PORT_FILE}" | tail -1 )"
  CURRENT_SOCAT_PORT_MSG=" to the port ${CURRENT_SOCAT_PORT} "  
else
  CURRENT_SOCAT_PORT=""
  CURRENT_SOCAT_PORT_MSG=" "
fi

CUR_IP_ADDRESS="$(  ifconfig -a | grep "inet " | grep -v 127.0.0 | awk '{ print $2 }' | cut -f2 -d ":"  )"
if [ "${CUR_IP_ADDRESS}"x = ""x ] ; then
  CUR_IP_ADDRESS="$( ip addr list | grep "inet " | grep -v 127.0.0 | awk '{ print $2 }' | cut -f1 -d "/" )"
fi

# ----------------------------------------------------------------------
# isNumber
#
# check if a value is an integer
#
# usage: isNumber testValue
#
# returns: ${__TRUE} - testValue is a number else not
#
function isNumber {

# this code does not work in the sh in Android
#  [[ $1 == +([0-9]) ]] && THISRC=${__TRUE} || THISRC=${__FALSE}

# old code:
  if [ "$1"x != ""x ] ; then
    TESTVAR="$(echo "$1" | sed 's/[0-9]*//g' )"
    [ "${TESTVAR}"x = ""x ] && return ${__TRUE} || return ${__FALSE}
  fi
  
  return ${__FALSE}
}

# ----------------------------------------------------------------------------

if [ "${CUR_IP_ADDRESS}"x != ""x ] ; then
  printMsg "The IP address configured is ${CUR_IP_ADDRESS}"
  CURRENT_IP_MSG=", the IP address is ${CUR_IP_ADDRESS}"
else
  printMsg "Currently is no IP address configured"
  CURRENT_IP_MSG=", no IP address found"
fi

if [ -r ${SOCAT_STOP_FILE} ] ; then
  LogDebugMsg  "Deleting the file \"${SOCAT_STOP_FILE}\" at $( date )"

  printMsg
  printMsg  "The port forwarding${CURRENT_SOCAT_PORT_MSG}is now enabled"
  printMsg 
  
  printMsg 
  printMsg "Press the ACTION button again 
  to disable the port forwarding"

  mv "${SOCAT_STOP_FILE}" "${SOCAT_STOP_FILE}.bkp"

# correct the module description
#
  sed -i -e "s/description=.*/description=Enable adb vi WiFi and configure port forwarding to a fixed TCP port (Port forwarding${CURRENT_SOCAT_PORT_MSG}is enabled${CURRENT_IP_MSG})/g" "${MODULE_PROP}"

else
  LogDebugMsg "Creating the file \"${SOCAT_STOP_FILE}\" at $( date )"

  printMsg
  printMsg "The port forwarding${CURRENT_SOCAT_PORT_MSG}is now disabled"
  printMsg
  printMsg "Press the ACTION button again 
  to enable the port forwarding"
 
  if [ -r "${SOCAT_STOP_FILE}.bkp" ] ; then
    mv "${SOCAT_STOP_FILE}.bkp" "${SOCAT_STOP_FILE}"
  else
    touch "${SOCAT_STOP_FILE}"
  fi

  if [ ${DEBUG_MODE} = ${__TRUE}  ] ; then
    SLEEP_INTERVALL="$( grep -E -v "^#|^$" "${SOCAT_STOP_FILE}" | tail -1 | tr "\t" " " | cut -f1 -d " " )"
    if ! isNumber ${SLEEP_INTERVALL} ; then
      SLEEP_INTERVALL=${DEFAULT_SLEEP_INTERVALL}
    fi
    printMsg 
    printMsg "The time to wait for the semaphor file is ${SLEEP_INTERVALL} seconds "
  fi

# correct the module description
#
  sed -i -e "s/description=.*/description=Enable adb vi WiFi and configure port forwarding to a fixed TCP port (Port forwarding${CURRENT_SOCAT_PORT_MSG}is disabled${CURRENT_IP_MSG})/g" "${MODULE_PROP}"

# stop the socat process if it's running
#
  SOCAT_PROCESS="$( ps -ef | grep -v grep  | grep " ${SOCAT} " | grep ":${CURRENT_SOCAT_PORT}" )"
  SOCAT_PROCESS_ID="$( echo "${SOCAT_PROCESS}" | awk '{ print $1 }' )"

  if [ "${SOCAT_PROCESS}"x = ""x ] ; then 
    SOCAT_PROCESS="$( ps -ef | grep -v grep  | grep " ${SOCAT_NAME} " | grep ":${CURRENT_SOCAT_PORT}" )"
    SOCAT_PROCESS_ID="$( echo "${SOCAT_PROCESS}" | awk '{ print $2 }' )"
  fi

  if [ "${SOCAT_PROCESS}"x != ""x ] ; then
    LogDebugMsg "The socat process is \"${SOCAT_PROCESS}\"  "
    if [ "${SOCAT_PROCESS_ID}"x != ""x ] ; then
      LogDebugMsg "Killing th socat process \"${SOCAT_PROCESS_ID}\"  "
      kill -9 ${SOCAT_PROCESS_ID}
    else
      LogDebugMsg "Can not retrieve the PID of the running socat process"
    fi
  else
    LogDebugMsg "No running socat process found"
  fi
  
fi



