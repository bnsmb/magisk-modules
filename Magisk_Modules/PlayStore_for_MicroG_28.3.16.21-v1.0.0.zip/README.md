
The Magisk Module contains the Playstore version 43.7.19.31

The Magisk Module was successfully tested in Android 13, 14, and 15

The Magisk Module requires an installed MicroG (https://microg.org/)

Documentation for creating Magisk Modules: https://topjohnwu.github.io/Magisk/guides.html
