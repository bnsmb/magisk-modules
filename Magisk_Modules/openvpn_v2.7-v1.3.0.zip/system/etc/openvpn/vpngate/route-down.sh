#!/system/bin/sh
ip rule del pref 10 from all lookup main

