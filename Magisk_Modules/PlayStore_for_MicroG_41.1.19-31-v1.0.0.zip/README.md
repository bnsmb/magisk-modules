
This Magisk Module contains the PlayStore version 41.1.19-31 for arm64 CPUs.

The Magisk Module has been successfully tested on Android 12, 13, 14, 15 and 16 (see below for detailed ROM information)

The Magisk Module requires MicroG (https://microg.org/) to be installed.

The customization script customize.sh from this Magisk Module disables the installed FakeStore from MicroG.
The customization script searches the installed FakeStore in these directories:

     /system/priv-app
     /system/product/priv-app
     /system/system_ext/priv-app
     /system/vendor/priv-app
     /product/priv-app
     /system_ext/priv-app
     /vendor/priv-app
 


Trouble Shooting

The PlayStore updates automatically. Depending on the used ROM the PlayStore may no longer work after the reboot with an updated PlayStore version.


Depending on the ROM used on the phone, the PlayStore may no longer work after restarting the phone with an updated PlayStore version.

If the PlayStore no longer works after the reboot of the phone, check the version of the active PlayStore either in the settings in the Android GUI or in an adb shell with this command:

dumpsys package com.android.vending  | grep versionName


e.g.:

In this example the PlayStore from the Magisk Module is still active:

ASUS_I006D:/ $  dumpsys package  com.android.vending  | grep versionName
    versionName=41.1.19-31 [0] [PR] 636190750
ASUS_I006D:/ $ 


In this example a PlayStore Update is active:

ASUS_I006D:/ $  dumpsys package  com.android.vending  | grep versionName
    versionName=47.9.30-31 [0] [PR] 805004130
    versionName=41.1.19-31 [0] [PR] 636190750
ASUS_I006D:/ $


If there is PlayStore update installed, simply uninstall the PlayStore update to restore the PlayStore to working order.


To uninstall the PlayStore update via the Android GUI, follow these steps:

         Force stop the PlayStore in the system settings.
         Clear the cache and memory for the PlayStore in the system settings.
         Uninstall the update for the PlayStore in the system settings.
         Restart the phone.



To simply this, you can also use the script

/system/bin/uninstall_playstore.sh

With this script, you can check which PlayStore version is currently active and also uninstall a PlayStore update.


The usage for the script is:

ASUS_I006D:/ $ /system/bin/uninstall_playstore_update.sh -h

 uninstall_playstore_update.sh v1.2.0 - uninstall a PlayStore update

 Usage: uninstall_playstore_update.sh  [-h|--help] [-H] [-d|--dryrun] [-x|--doit] [-f|--force] [-c|--clean] [-r|--reboot] [-v|--verbose] [-V|--version] [var=value]

 Use the parameter "-H" to print the detailed usage help

ASUS_I006D:/ $
 


The detailed usage help for the script is

/system/bin/uninstall_playstore_update.sh -H

ASUS_I006D:/ $ /system/bin/uninstall_playstore_update.sh -H

 uninstall_playstore_update.sh v1.2.0 - uninstall a PlayStore update

 Usage: uninstall_playstore_update.sh  [-h|--help] [-H] [-d|--dryrun] [-x|--doit] [-f|--force] [-c|--clean] [-r|--reboot] [-v|--verbose] [-V|--version] [var=value]

 Known parameter:
 
 -h               print the short usage help
 -H               print the detailed usage help
 -d               run the script in dry-run mode
 -x               delete the PlayStore update if the PlayStore is currently not running
 -f               delete the PlayStore update even if the PlayStore is currently running
 -c               cleanup the update and cache directories for the PlayStore
 -r               reboot the phone after deleting the PlayStore update
 -v               print more messages
 -V               print the script version and exit
 var=value        set the variable "var" to the value "value"

 Return codes:

   0 - no PlayStore update found
   1 - PlayStore update found but not deleted
   2 - PlayStore update deleted; reboot required
   3 - PlayStore update found and the PlayStore is running
   4 - no installed PlayStore found
   5 - cache directories deleted

 Set the variable PREFIX to "echo" or something similar to run the script in dry-run mode
 Set the environment variable TRACE to any value to run the script with "set -x"


ASUS_I006D:/ $ 



To check, which PlayStore version is currently active, run the script without parameters.

Example:

# output of the script if no PlayStore update is currently installed

ASUS_I006D:/ $  uninstall_playstore_update.sh
Restarting the script as user "root" ...
The active PlayStore version is 41.1.19-31 [0] [PR] 636190750
The PlayStore is running
The version of the initial installed PlayStore apk file "/product/priv-app/Phonesky/Phonesky.apk" is 41.1.19-31
No PlayStore update found (The current path to the PlayStore is "/product/priv-app/Phonesky/Phonesky.apk" )

4|ASUS_I006D:/ $


# output of the script if a PlayStore update is currently installed

ASUS_I006D:/ $ uninstall_playstore_update.sh
Restarting the script as user "root" ...
The active PlayStore version is 47.9.30-31 [0] [PR] 805004130
The PlayStore is running
The version of the initial installed PlayStore apk file "/product/priv-app/Phonesky/Phonesky.apk" is 41.1.19-31
There is an update for the PlayStore installed in the directory "/data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/":

drwxrwxr-x 4 system system   u:object_r:apk_data_file:s0              3452 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/
-rw-r--r-- 1 system system   u:object_r:apk_data_file:s0          52723787 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/base.apk
drwxr-xr-x 3 system system   u:object_r:apk_data_file:s0              3452 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/lib
drwxr-xr-x 2 system system   u:object_r:apk_data_file:s0              3452 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/lib/arm64
drwxr-x--x 3 system system   u:object_r:dalvikcache_data_file:s0      3452 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/oat
drwxr-x--x 2 system system   u:object_r:dalvikcache_data_file:s0      3452 2025-09-11 17:45 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/oat/arm64
-rw-r----- 1 system all_a119 u:object_r:dalvikcache_data_file:s0   4192416 2025-09-11 17:45 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/oat/arm64/base.art
-rw-r----- 1 system all_a119 u:object_r:dalvikcache_data_file:s0  51776808 2025-09-11 17:45 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/oat/arm64/base.odex
-rw-r----- 1 system all_a119 u:object_r:dalvikcache_data_file:s0   1402372 2025-09-11 17:45 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/oat/arm64/base.vdex
-rw-r--r-- 1 system system   u:object_r:apk_data_file:s0           9192222 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/split_config.arm64_v8a.apk
-rw-r--r-- 1 system system   u:object_r:apk_data_file:s0            499922 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/split_config.en.apk
-rw-r--r-- 1 system system   u:object_r:apk_data_file:s0             16534 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/split_phonesky_data_loader.apk
-rw-r--r-- 1 system system   u:object_r:apk_data_file:s0             65772 2025-09-11 17:09 /data/app/~~up_dFF_WvXfEgz6isubTag==/com.android.vending-4w0bwM-5Yh0lYIuyEwqEbg==/split_phonesky_data_loader.config.arm64_v8a.apk

The version of the apk file with the PlayStore update is 47.9.30-31
Nothing to do right now (use the parameter "-f" or "--force" to uninstall the PlayStore update anyway

3|ASUS_I006D:/ $




The command to uninstall the PlayStore update in any case and reboot the phone if necessary is

su - -c  /system/bin/uninstall_playstore_update.sh -r -f


To automatically uninstall a non-functioning PlayStore update after a restarting your phone, create this symbolic link after installing this Magisk Module:


su - -c ln -s ./system/bin/uninstall_playstore_update.sh /data/adb/modules/PlayStore_for_MicroG/uninstall_playstore_update.sh


Note that after deleting the PlayStore update, the phone will automatically restart again. This reboot is necessary to reread the permissions for the PlayStore.

Be aware that the PlayStore automatically updates again after the reboot. The updated PlayStore will work again until the next time the phone is rebooted.



Details

The PlayStore is installed in the directory /product/priv-app/Phonesky and the permssion files are in the directory /product/etc/permissions.

The Magisk Module also contains the executable aapt2. If an executable aapt2 is already installed, the aapt2 executable from this Magisk Module will be renamed to aapt2.new.
 


The documentation for this Magisk Module is here:

https://bnsmb.de/My_HowTos_for_Android.html#How_to_replace_the_FakeStore_in_MicroG_with_the_original_PlayStore


The documentation for creating Magisk Modules is here: 

https://topjohnwu.github.io/Magisk/guides.html


Test Environment

Version 41.1.19-31-v1.0.0 of this Magisk Module has been successfully tested (including a PlayStore update and reboot) with the following ROMs:

  OmniROM 12 (Android 12)
  OmniROM 13 (Android 13)
  OmniROM 14 (Android 14)
  OmniROM 15 (Android 15)
  OmniROM 16 (Android 16)

  /e/ 3.0.4-t (Android 13; LineageOS based)
  /e/ 3.0.4-a15 (Android 15; LineageOS based)

  LineageOS 20.x (Android 13)


The PlayStore from this Magisk Module does not wwork in

  LineageOS 22.x (Android 15, tested only on the ASUS Zenfone 8)


History

  11.09.2025 41.1.19-31-v1.0.0 
    initial release

