
The Magisk Module contains the Playstore version 28.3.16.21 for arm64 CPUs

The Magisk Module was successfully tested in Android 13, 14, and 15

The Magisk Module requires an installed MicroG (https://microg.org/)

The Magisk Module disables an installed FakeStore from MicroG.

The customize script searches the FakeStore in these directories:

     /system/priv-app
     /system/product/priv-app
     /system/system_ext/priv-app
     /system/vendor/priv-app
     /product/priv-app
     /system_ext/priv-app
     /vendor/priv-app
 


Documentation for creating Magisk Modules: https://topjohnwu.github.io/Magisk/guides.html

History

  28.3.16.21-v1.1.0 
    initial release

  03.09.2025 28.3.16.21-v1.1.0
    the customize script now searches the FakeStore in the directories
      /system/priv-app
      /system/product/priv-app
      /system/system_ext/priv-app
      /system/vendor/priv-app
      /product/priv-app
      /system_ext/priv-app
      /vendor/priv-app
 
