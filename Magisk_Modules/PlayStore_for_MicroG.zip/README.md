
## Customiztion script for the Magisk Module PlayStore_for_MicroG

(see customize.sh for the release history)

## Notes

This Magisk Module is for **ARM64 CPUs only**

The files for the playstore are from the NanoDroid:  [NanoDroid](https://nanolx.org/)

Documentation for creating Magisk Modules: [Magisk Develop Documentation](https://topjohnwu.github.io/Magisk/guides.html)
