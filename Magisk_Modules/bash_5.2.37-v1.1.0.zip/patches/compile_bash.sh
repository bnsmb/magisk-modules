echo "Compile bash dynamically linked for only the Android OS libraries ..."


/data/local/tmp/sysroot/usr/clang19/bin/clang \
 -L./builtins \
 -L./lib/readline \
 -L./lib/readline \
 -L./lib/glob \
 -L./lib/tilde \
  \
 -L./lib/sh \
  \
 -L/data/local/tmp/sysroot/usr/lib \
 -L/data/local/tmp/sysroot/usr/ndk/r27b/sysroot/usr/lib/aarch64-linux-android/31 \
 -L/data/local/tmp/sysroot/usr/ndk/r27b/sysroot/usr/lib/aarch64-linux-android \
 -L/data/local/tmp/develop/sysroot/usr/lib \
 -B/data/local/tmp/sysroot/usr/ndk/r27b/sysroot/usr/lib/aarch64-linux-android/31/ \
 --sysroot=/data/local/tmp/sysroot/usr/ndk/r27b/sysroot \
 -lc \
  \
  \
  \
 -rdynamic \
 -I/data/local/tmp/sysroot/usr/include \
 -I/data/local/tmp/sysroot/usr/clang19/include \
 -I/data/local/tmp/sysroot/usr/ndk/r27b/include \
 -I/data/local/tmp/sysroot/usr/ndk/r27b/sysroot/usr/include/aarch64-linux-android \
 -I/data/local/tmp/sysroot/usr/ndk/r27b/sysroot/usr/include \
 -I/data/local/tmp/develop/sysroot/usr/include \
 --sysroot=/data/local/tmp/sysroot/usr/ndk/r27b/sysroot \
 -Wno-implicit-function-declaration \
 -Wno-int-conversion \
  \
  \
  \
  \
 -o \
 bash \
 shell.o \
 eval.o \
 y.tab.o \
 general.o \
 make_cmd.o \
 print_cmd.o \
  \
 dispose_cmd.o \
 execute_cmd.o \
 variables.o \
 copy_cmd.o \
 error.o \
 expr.o \
 flags.o \
 jobs.o \
 subst.o \
 hashcmd.o \
 hashlib.o \
 mailcheck.o \
 trap.o \
 input.o \
 unwind_prot.o \
 pathexp.o \
 sig.o \
 test.o \
 version.o \
 alias.o \
 array.o \
 arrayfunc.o \
 assoc.o \
 braces.o \
 bracecomp.o \
 bashhist.o \
 bashline.o \
  \
 list.o \
 stringlib.o \
 locale.o \
 findcmd.o \
 redir.o \
 pcomplete.o \
 pcomplib.o \
 syntax.o \
 xmalloc.o \
  \
 -lbuiltins \
 -lglob \
 -lsh \
 /data/local/tmp/develop/sysroot/usr/lib/libreadline.a \
 /data/local/tmp/develop/sysroot/usr/lib/libhistory.a \
 /data/local/tmp/develop/sysroot/usr/lib/libtinfo.a \
 -ltilde \
  \
 /data/local/tmp/develop/sysroot/usr/lib/libiconv.a \
 /data/local/tmp/develop/sysroot/usr/lib/libtinfo.a \
 -Wl,-rpath \
 -Wl,/data/local/tmp/develop/sysroot/usr/lib \
  \
 /data/local/tmp/develop/sysroot/usr/lib/libiconv.a \
 -Wl,-rpath \
 -Wl,/data/local/tmp/develop/sysroot/usr/lib \
  \
 -ldl \

ls -l bash
echo
ldd $PWD/bash

