
/data/local/tmp/sysroot/usr/clang19/bin/clang \
 -L/data/local/tmp/sysroot/usr/lib \
 -L/data/local/tmp/sysroot/usr/ndk/r27d/sysroot/usr/lib/aarch64-linux-android/31 \
 -L/data/local/tmp/sysroot/usr/ndk/r27d/sysroot/usr/lib/aarch64-linux-android \
 -L/data/local/tmp/develop/sysroot/usr/lib \
 -B/data/local/tmp/sysroot/usr/ndk/r27d/sysroot/usr/lib/aarch64-linux-android/31/ \
 --sysroot=/data/local/tmp/sysroot/usr/ndk/r27d/sysroot \
 -lc \
 /data/local/tmp/develop/sysroot/usr/lib/libncursesw.a \
 -Xlinker \
 -export-dynamic \
 -o python3.15-static \
 Programs/python.o \
 libpython3.15.a \
 -ldl \
 -llog \
 -lm

if [ $? -eq 0 ] ; then
  cp python3.15-static python3.15-static-stripped
  llvm-strip --strip-all python3.15-static-stripped

  ls -lhd python3.15-static*

  file python3.15-static*

  myldd python3.15-static*

fi


