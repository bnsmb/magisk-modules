# -----------------------------------------------------------------------------
# log STDOUT and STDERR to a file
#
exec 2>/data/cache/uninstall_playstore.log 1>&2
set -x

echo "Existing files used by the PlayStore that will be deleted"

ls -lZ /data/app/*/com.android.vending*

ls -lZ /data/system/package_cache/*/*com.android.vending*

ls -lZ /data/user/0/com.android.vending/

# delete PlayStore updates (uninstall_playstore_update.sh does not work when this script is executed)
#
rm -rf /data/app/*/com.android.vending*

rm -rf /data/system/package_cache/*/*com.android.vending*

rm -rf /data/user/0/com.android.vending/


# Don't modify anything after this
if [ -f $INFO ]; then
  while read LINE; do
    if [ "$(echo -n $LINE | tail -c 1)" == "~" ]; then
      continue
    elif [ -f "$LINE~" ]; then
      mv -f $LINE~ $LINE
    else
      rm -f $LINE
      while true; do
        LINE=$(dirname $LINE)
        [ "$(ls -A $LINE 2>/dev/null)" ] && break 1 || rm -rf $LINE
      done
    fi
  done < $INFO
  rm -f $INFO
fi
