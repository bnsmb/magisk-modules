package Test2::Util::Table::Cell;
use strict;
use warnings;

our $VERSION = '1.302214';

use base 'Term::Table::Cell';

1;
