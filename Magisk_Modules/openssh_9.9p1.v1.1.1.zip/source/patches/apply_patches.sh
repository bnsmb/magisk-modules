

function mycp {

  if [ ! -r $2 ] ; then
    cp $1 $2
  else
    echo "$2 already exist"
  fi
}

set -x

echo ; echo Patching  auth.c 
mycp ../auth.c ../auth.c.org 
patch ../auth.c  auth.c.patch 

echo ; echo Patching  auth-passwd.c 
mycp ../auth-passwd.c ../auth-passwd.c.org 
patch ../auth-passwd.c  auth-passwd.c.patch 

echo ; echo Patching  defines.h 
mycp ../defines.h ../defines.h.org 
patch ../defines.h  defines.h.patch 

echo ; echo Patching  hostfile.c 
mycp ../hostfile.c ../hostfile.c.org 
patch ../hostfile.c  hostfile.c.patch 

echo ; echo Patching  loginrec.c 
mycp ../loginrec.c ../loginrec.c.org 
patch ../loginrec.c  loginrec.c.patch 

echo ; echo Patching  misc.c 
mycp ../misc.c ../misc.c.org 
patch ../misc.c  misc.c.patch 

echo ; echo Patching misc.c -- Additional Patch for UID 2000
patch ../misc.c misc.c.additional.patch


echo ; echo Patching  mux.c 
mycp ../mux.c ../mux.c.org 
patch ../mux.c  mux.c.patch 


echo ; echo Patching  pathnames.h 
mycp ../pathnames.h ../pathnames.h.org 
patch ../pathnames.h  pathnames.h.patch 

echo ; echo Patching  readconf.c 
mycp ../readconf.c ../readconf.c.org 
patch ../readconf.c  readconf.c.patch 

echo ; echo Patching  servconf.c 
mycp ../servconf.c ../servconf.c.org 
patch ../servconf.c  servconf.c.patch 

echo ; echo Patching  session.c 
mycp ../session.c ../session.c.org 
patch ../session.c  session.c.patch 

echo ; echo Patching  sftp-server.c 
mycp ../sftp-server.c ../sftp-server.c.org 
patch ../sftp-server.c  sftp-server.c.patch 

echo ; echo Patching  ssh-agent.c 
mycp ../ssh-agent.c ../ssh-agent.c.org 
patch ../ssh-agent.c  ssh-agent.c.patch 

echo ; echo Patching  ssh_config 
mycp ../ssh_config ../ssh_config.org 
patch ../ssh_config  ssh_config.patch 

echo ; echo Patching  sshd_config.5 
mycp ../sshd_config.5 ../sshd_config.5.org 
patch ../sshd_config.5  sshd_config.5.patch 


echo ; echo Patching  sshd_config 
mycp ../sshd_config ../sshd_config.org 
patch ../sshd_config  sshd_config.patch 

echo ; echo Patching  sshd.c 
mycp ../sshd.c ../sshd.c.org 
patch ../sshd.c  sshd.c.patch 

echo ; echo Patching  sshd-session.c 
mycp ../sshd-session.c ../sshd-session.c.org 
patch ../sshd-session.c  sshd-session.c.patch 

echo ; echo Patching  ssh-keygen.c 
mycp ../ssh-keygen.c ../ssh-keygen.c.org 
patch ../ssh-keygen.c  ssh-keygen.c.patch 

echo ; echo Patching  sshpty.c 
mycp ../sshpty.c ../sshpty.c.org 
patch ../sshpty.c  sshpty.c.patch 

echo ; echo Patching echo ; echo Patching echo ; echo Patching echo ; echo Patching 

echo ; echo Patching  contrib_ssh-copy-id 
cp  ../contrib/ssh-copy-id ../contrib/ssh-copy-id.org 
patch  ../contrib/ssh-copy-id contrib_ssh-copy-id.patch 

echo ; echo Patching  openbsd-compat_explicit_bzero.c 
mycp ../openbsd-compat/explicit_bzero.c ../openbsd-compat/explicit_bzero.c.org 
patch  ../openbsd-compat/explicit_bzero.c openbsd-compat_explicit_bzero.c.patch 

echo ; echo Patching  openbsd-compat_xcrypt.c 
cp  ../openbsd-compat/xcrypt.c ../openbsd-compat/xcrypt.c.org 
patch ../openbsd-compat/xcrypt.c  openbsd-compat_xcrypt.c.patch 





