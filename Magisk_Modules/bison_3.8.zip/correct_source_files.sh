 set -x
 
 sed -i -e "s#/usr/bin/m4#/system/bin/m4#g" system/bin/*

 sed -i -e "s#/usr/bin/perl#/system/bin/perl#g" system/bin/*

