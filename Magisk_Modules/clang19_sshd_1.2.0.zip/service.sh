# 
# Magisk init script service.sh for the Magisk Module to start/stop the sshd from the clang19 toolchain
#
# History
#   12.03.2026 /bs
#     initial release
#
# use the command
#
#   resetprop -w sys.boot_completed 0
#
# to wait until the boot is complete
#
# Note: Do NOT use typeset in this script!
#
# -----------------------------------------------------------------------------
# define some constants
#
__TRUE=0
__FALSE=1

export IN_SERVICE_SCRIPT=${__TRUE}

# -----------------------------------------------------------------------------
#
# the environment variable MODPATH is only defined by Magisk for the script customize.sh
#
[ "${MODPATH}"x = ""x ] && MODPATH="${0%/*}"

MODULE_NAME="$( grep "^id=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"
[ "${MODULE_NAME}"x = ""x ] && MODULE_NAME="unknown_magisk_module"

MODULE_VERSION="$( grep "^version=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"

MODULE_DESC="${MODULE_NAME} ${MODULE_VERSION}"

# customize.sh is sourced in
# #
[ "$0"x = "sh"x ] && SCRIPT_NAME="customize.sh" || SCRIPT_NAME="${0##*/}"


# ----------------------------------------------------------------------------
# create a semphor to  avoid duplicate parallel execution 
#  
mkdir /dev/"${MODULE_NAME}" || exit


# ----------------------------------------------------------------------------
#
# LogDebugMsg - print a Message if DEBUG_MODE is ${__TRUE}
# 
# Usage: LogDebugMsg [message]
#
function LogDebugMsg {
  if [ ${DEBUG_MODE} = ${__TRUE} ] ; then
    echo "$*"
  fi
}

# -----------------------------------------------------------------------------
# change either "0 = 1" to "0 = 0" in this script or create the file /data/local/tmp/debug to enable the debug output to the log file
#
if [ 0 = 1 -o -r /data/local/tmp/debug ] ; then
  LOGFILE="/data/local/tmp/${MODULE_NAME}_${SCRIPT_NAME}.log"

#  echo "Writing all messages to the log file ${LOGFILE}"

  exec 1>"${LOGFILE}" 2>&1

  echo "The PID of this process is $$; the PPID is $PPID"
  
  if [ -r /data/local/tmp/trace ] ; then
    set -x
    TRACE_MODE=${__TRUE}
  else
    TRACE_MODE=${__FALSE}    
  fi
  
  DEBUG_MODE=${__TRUE}   
else
  DEBUG_MODE=${__FALSE}     
  TRACE_MODE=${__FALSE}  
fi

# -----------------------------------------------------------------------------

function get_sshd_port {
  CUR_PORT=$( su - ${SHELL_USER} -c /data/local/tmp/sysroot/usr/sbin/sshd -T | grep "^port" | awk '{ print $2}' )
  [ "${CUR_PORT}"x != ""x ] && echo "(listening on port ${CUR_PORT})"
}

# -----------------------------------------------------------------------------

# wait until the boot is complete:
#
resetprop -w sys.boot_completed 0

CLANG19_SYSROOT="/data/local/tmp/sysroot"

SSHD="${CLANG19_SYSROOT}/usr/sbin/sshd"

SHELL_USER="shell"

START_SEMAPHOR="${CLANG19_SYSROOT}/start_sshd"

if [ -r "${START_SEMAPHOR}" ] ; then
  echo "Automatic start of the sshd from the clang19 toolchain is requested"

  if [ -x "${SSHD}" ] ; then
    echo "Now starting the sshd ...."
    su - ${SHELL_USER} -c ${SSHD}
    SSHD_LINE=$( /system/bin/ps -u ${SHELL_USER} -f | grep "sshd$" | tail -1 )
    if [ "${SSHD_LINE}"x = ""x ] ; then
      echo "ERROR: Could not start the sshd"
    else
      echo "OK, sshd started:"
      echo "${SSHD_LINE}"
      sed -i -e "s/^description=.*/description=The sshd from clang19 is currently running $( get_sshd_port )/g" ${MODPATH}/module.prop
    fi
  else
    echo "ERROR: The file \"${SSHD}\" does not exist or is not executable"
    sed -i -e "s/^description=.*/description=The sshd from clang19 is currently NOT running/g" ${MODPATH}/module.prop
  fi
else
  echo "Automatic start of the sshd from the clang19 toolchain is NOT requested"
  sed -i -e "s/^description=.*/description=The sshd from clang19 is currently NOT running/g" ${MODPATH}/module.prop  
fi

# -----------------------------------------------------------------------------
# remove the semaphor if it exists
#
[ -d "/dev/${MODULE_NAME}" ] && \rmdir /dev/${MODULE_NAME}

# -----------------------------------------------------------------------------
