
# 
# Magisk script action.sh for the Magisk Module to start/stop the sshd from the clang19 toolchain
#
# Note: All messages written to STDOUT are displayed in the Magisk output window 
#
# History
#  12.03.2026 /bs
#     initial release
#  03.04.2026 /bs
#     the script now reads the VolumeUp and VolumeDownKeys
#     added the semaphor file /data/adb/modules/<modulename>/IGNORE_PHYSICAL_KEYS
#
#     
# Note: Do NOT use typeset in this script!
#
# If the file /data/adb/modules/<modulename>/IGNORE_PHYSICAL_KEYS exists; the script ignores 
# phyiscal keys
#

# -----------------------------------------------------------------------------
# define some constants
#
__TRUE=0
__FALSE=1

export IN_ACTION__SCRIPT=${__TRUE}

# constants for the physical keys
#
NO_KEY_PRESSED=0
VOLUME_UP_PRESSED=1
VOLUME_DOWN_PRESSED=2
POWER_PRESSED=3


# -----------------------------------------------------------------------------
#
# the environment variable MODPATH is only defined by Magisk for the script customize.sh
#
[ "${MODPATH}"x = ""x ] && MODPATH="${0%/*}"

MODULE_NAME="$( grep "^id=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"
[ "${MODULE_NAME}"x = ""x ] && MODULE_NAME="unknown_magisk_module"

MODULE_VERSION="$( grep "^version=" ${MODPATH}/module.prop  | cut -f2 -d "=" )"

MODULE_DESC="${MODULE_NAME} ${MODULE_VERSION}"

# customize.sh is sourced in
# #
[ "$0"x = "sh"x ] && SCRIPT_NAME="customize.sh" || SCRIPT_NAME="${0##*/}"

SEMFILE="${MODPATH}/IGNORE_PHYSICAL_KEYS"

# -----------------------------------------------------------------------------
# save the file handle for STDOUT to file handle 5 ( &5 is used in the function printMsg )
#
exec 5>&1

# ----------------------------------------------------------------------------
#
# printMsg - print a Message to the Magisk output window even if redirection of STDOUT to the logfile is enabled
# 
# Usage: printMsg [message]
#
function printMsg {
   echo "$*" >&5
}

# ----------------------------------------------------------------------------
#
# LogDebugMsg - print a Message if DEBUG_MODE is ${__TRUE}
# 
# Usage: LogDebugMsg [message]
#
function LogDebugMsg {
  if [ ${DEBUG_MODE} = ${__TRUE} ] ; then
    echo "$*"
  fi
}

# ---------------------------------------------------------------------
# ReadVolumeKeys - read the status of the volume keys
#
# Usage: ReadVolumeKeys [timeout] 
#
# Parameter:
#        timeout - timeout in seconds to wait; the default value is 10 seconds
#
# returns:
#        0 - no volume key pressed (NO_KEY_PRESSED)
#        1 - volume up pressed (VOLUME_UP_PRESSED)
#        2 - volume down pressed (VOLUME_DOWN_PRESSED)
#        3 - power key pressed (POWER_PRESSED)
#
function ReadVolumeKeys {
  local __FUNCTION="ReadVolumeKeys"

  local THISRC=${NO_KEY_PRESSED}
   
  local DEFAULT_TIMEOUT=10
  
  local TIMEOUT="${DEFAULT_TIMEOUT}"
  local MESSAGE=""
  
  local dev=""
  local type=""
  local code=""
  local value=""
  
  local RESULT=""

  if [ $# -eq 1 ] ; then
    TIMEOUT=$1
    shift
  fi

# the variables dev, type, code, and value can not be used here because the "while" statement is running a separate session
#
  RESULT=$( timeout ${TIMEOUT} getevent -ql | while read dev type code value; do
    if [ "$code" = "KEY_VOLUMEUP" ] && [ "$value" = "DOWN" ]; then
      echo ${VOLUME_UP_PRESSED}
      break
    elif [ "$code" = "KEY_VOLUMEDOWN" ] && [ "$value" = "DOWN" ]; then
      echo ${VOLUME_DOWN_PRESSED}
      break
    elif  [ "$code" = "KEY_POWER" ] && [ "$value" = "DOWN" ]; then

# activate the display again (no pin necessary here -- at least in my tests ....)
# 
      input keyevent KEYCODE_WAKEUP
      echo ${POWER_PRESSED}
      break
    fi
  done )
   
  [ "${RESULT}"x != ""x ] && THISRC="${RESULT}"
  
  return ${THISRC}
}

# -----------------------------------------------------------------------------
# change either "0 = 1" to "0 = 0" in this script or create the file /data/local/tmp/debug to enable the debug output to the log file
#
if [ 0 = 1  -o -r /data/local/tmp/debug ] ; then
  LOGFILE="/data/local/tmp/${MODULE_NAME}_${SCRIPT_NAME}.log"

  printMsg  "----"
  printMsg  "Messages to STDOUT are now redirected to the log file 
  ${LOGFILE}"
  printMsg  "----"

  exec 1>"${LOGFILE}" 2>&1

  echo "The PID of this process is $$; the PPID is $PPID"

  if [ -r /data/local/tmp/trace ] ; then
    set -x
    TRACE_MODE=${__TRUE}
  else
    TRACE_MODE=${__FALSE}    
  fi

  DEBUG_MODE=${__TRUE}   
else
  DEBUG_MODE=${__FALSE}     
  TRACE_MODE=${__FALSE}
fi

# ----------------------------------------------------------------------------
# change the if clause to disable the example code
#
if [ 1 = 0 ] ; then
  printMsg "This message goes to the Magisk Output Window 
even if STDOUT is redirected to a file"

  echo "This message goes to the Magisk Output 
window if STDOUT is NOT redirected;
it goes to the logfile if STDOUT is redirected to a file"

  echo "This messages goes to the log file if STDERR 
is redirected to a file. It goes to the Nirvana if STDERR 
is NOT redirected" >&2

fi

# -----------------------------------------------------------------------------

function get_sshd_port {
  CUR_PORT=$( su - ${SHELL_USER} -c /data/local/tmp/sysroot/usr/sbin/sshd -T | grep "^port" | awk '{ print $2}' )
  [ "${CUR_PORT}"x != ""x ] && echo "(listening on port ${CUR_PORT})"
}

CLANG19_SYSROOT="/data/local/tmp/sysroot"

SSHD="${CLANG19_SYSROOT}/usr/sbin/sshd"

SHELL_USER="shell"


SSHD_LINE=$( /system/bin/ps -u ${SHELL_USER} -f | grep "sshd$" | tail -1  )
SSHD_PID="$( echo "${SSHD_LINE}" | awk '{ print $2}' )"
 
 
if [ "${SSHD_PID}"x != ""x ] ; then
  echo
  echo "The sshd from the clang19 toolchain is running:"
  echo
  echo "${SSHD_LINE}"
  echo 
  echo 

  if [ -r "${SEMFILE}" ] ; then
    THISRC=${NO_KEY_PRESSED}
  else
    echo "It's now $(date +%H:%M:%S ); press "
    echo
    echo "<VolumeDown> to stop the sshd"
    echo "<VolumeUp> to NOT stop the sshd"
    echo "or wait 5 seconds to stop the sshd"
    
    ReadVolumeKeys
    THISRC=$?
  fi

  if [ ${THISRC} -eq ${NO_KEY_PRESSED} -o ${THISRC} -eq ${VOLUME_DOWN_PRESSED} ] ; then
    echo "Now stopping the sshd ..."
    kill ${SSHD_PID} || ( sleep 1 ; kill -9 ${SSHD_PID} )
    SSHD_LINE=$( /system/bin/ps -u ${SHELL_USER} -f | grep "sshd$" | tail -1 | awk '{ print $2}' )
    if [ "${SSHD_LINE}"x != ""x ] ; then
      echo "ERROR: Could not stop the sshd:"
      echo "${SSHD_LINE}"
      
      sed -i -e "s/^description=.*/description=The sshd from clang19 is currently running $( get_sshd_port) /g" ${MODPATH}/module.prop
      
    else
      echo "OK, sshd stopped"
      sed -i -e "s/^description=.*/description=The sshd from clang19 is currently NOT running/g" ${MODPATH}/module.prop
  
    fi
  else
    echo "VolumeUp or Power pressed - not stopping the sshd"
  fi
else
  echo
  echo "The sshd from the clang19 toolchain is not running:"
  echo

  if [ -r "${SEMFILE}" ] ; then
    THISRC=${NO_KEY_PRESSED}
  else
    echo "It's now $(date +%H:%M:%S ); press "
    echo
    echo "<VolumeDown> to start the sshd"
    echo "<VolumeUp> to NOT start the sshd"
    echo "or wait 5 seconds to start the sshd"
    
    ReadVolumeKeys
    THISRC=$?
  fi

  if [ ${THISRC} -eq ${NO_KEY_PRESSED} -o ${THISRC} -eq ${VOLUME_DOWN_PRESSED} ] ; then
    if [ -x "${SSHD}" ] ; then
      echo "Now starting the sshd ...."
      su - ${SHELL_USER} -c ${SSHD}
      SSHD_LINE=$( /system/bin/ps -u ${SHELL_USER} -f | grep "sshd$" | tail -1 )
      if [ "${SSHD_LINE}"x = ""x ] ; then
        echo "ERROR: Could not start the sshd"
      else
        echo "OK, sshd started:"
        echo "${SSHD_LINE}"
        sed -i -e "s/^description=.*/description=The sshd from clang19 is currently running $( get_sshd_port) /g" ${MODPATH}/module.prop
      fi
    else
      echo "ERROR: The file \"${SSHD}\" does not exist or is not executable"
      sed -i -e "s/^description=.*/description=The sshd from clang19 is currently NOT running/g" ${MODPATH}/module.prop      
    fi
  else
    echo "VolumeUp or Power pressed - not starting the sshd"
  fi    
fi

# -----------------------------------------------------------------------------



  

