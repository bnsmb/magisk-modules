VS_SDK_REFERENCES
-----------------

.. versionadded:: 3.7

Visual Studio project SDK references.
Specify a :ref:`semicolon-separated list <CMake Language Lists>` of SDK references
to be added to a generated Visual Studio project, e.g.
``Microsoft.AdMediatorWindows81, Version=1.0``.
