ARCHIVE_OUTPUT_DIRECTORY
------------------------

.. |XXX| replace:: :ref:`ARCHIVE <Archive Output Artifacts>`
.. |xxx| replace:: archive
.. |CMAKE_XXX_OUTPUT_DIRECTORY| replace:: :variable:`CMAKE_ARCHIVE_OUTPUT_DIRECTORY`
.. include:: XXX_OUTPUT_DIRECTORY.txt

.. |IDEM| replace:: in the same directory
.. include:: MACOS_IMPORT_FILES.txt

See also the :prop_tgt:`ARCHIVE_OUTPUT_DIRECTORY_<CONFIG>` target property.
