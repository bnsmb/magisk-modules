Fortran_BUILDING_INSTRINSIC_MODULES
-----------------------------------

.. deprecated:: 4.0

  Please use the :prop_tgt:`Fortran_BUILDING_INTRINSIC_MODULES` instead.

.. versionadded:: 3.22

A misspelled variant of the :prop_tgt:`Fortran_BUILDING_INTRINSIC_MODULES`
target property.
