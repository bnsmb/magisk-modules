VS_FILTER_PROPS
---------------

.. versionadded:: 3.30

Sets the filter props file to be included in the visual studio
C++ project filter file.

The ``*.filter.props`` files can be used for Visual Studio wide
configuration which is independent from cmake.
