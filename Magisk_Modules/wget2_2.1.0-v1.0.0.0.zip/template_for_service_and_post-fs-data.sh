#!/system/bin/sh
MODDIR=${0%/*}
# this points to /data/adb/modules/<module_name>
MODULE=$(dirname $0)
MNAME=$(basename $MODDIR)

