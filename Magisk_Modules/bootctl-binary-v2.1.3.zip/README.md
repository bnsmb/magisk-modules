<h1 align="center">Magisk Bootctl Binary</h1>

This is a simple Magisk Module for adding the bootctl binary. It is used for A/B slot handling.<br>
It can be executed from terminal (with su) or with a GUI wrapper like <a href="https://github.com/gibcheesepuffs/Switch-My-Slot-Android">Switch My Slot</a>.

The bootctl binary is taken from this <a href="https://github.com/topjohnwu/magisk_files">repo</a>.

This module is based on <a href="https://github.com/Zackptg5/MMT-Extended">MMT-Ex</a>.

Update 21.09.2022 /bs

- The original source for this Magisk Module is here:  <a href="https://github.com/roihershberg/bootctl-binary">bootctl-binary repository</a>
  According to the maintainer this repository is not updated anymore

- changed the max. API version in customize.sh to 32 so that the module can be installed in Android 12

- renamed the binary to bootctl.bin

- added the wrapper script bootctl to start bootctl because the directory /vendor/lib64 with the necessary libraries for the binary is not in the default library path in Android 12


