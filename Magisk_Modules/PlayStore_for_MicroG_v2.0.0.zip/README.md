
This Magisk Module is for **ARM64 CPUs only**

Supported Android versions are:

    Android 15  Playstore Version 42.3.24-31 (Source: https://sourceforge.net/projects/nikgapps/ )
    Android 14  Playstore Version 43.7.19.31 (Source: installed via https://github.com/Psk-Ita/microG-GApps)
    Android 13  Playstore Version 43.7.19-31 (Source: https://sourceforge.net/projects/nikgapps/ )

To update the Playstore in this Magisk Module do

    unzip the ZIP file in an empty directory
    replace or edit the files in the directory for the Android version ( ./13, ./14, or ./15; to support a new Android version 
      just create the directory for it, e.g. for Android 16 create the directory ./16 and copy the files to that directory)
    edit the version in the file ./module.prop 
    (optional) edit the file README
    create the new zip file by executing the script ./create_zip.sh from the ZIP file (create_zip.sh is a shell script for Linux)


Documentation for creating Magisk Modules: https://topjohnwu.github.io/Magisk/guides.html
