ZIPFILE="../$( grep "^name=" module.prop | cut -f2 -d "=" )_$( grep "^version=" module.prop | cut -f2 -d "=" | tr " " "_" ).zip" 
echo ""
echo "*** Creating the ZIP file \"${ZIPFILE}\" ..."
[ -r "${ZIPFILE}" ] && \rm -f "${ZIPFILE}"
zip -y -r "${ZIPFILE}" .

echo ""
ls -l "${ZIPFILE}"
